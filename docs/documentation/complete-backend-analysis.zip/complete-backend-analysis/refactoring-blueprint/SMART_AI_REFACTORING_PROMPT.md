# SMART AI REFACTORING PROMPT - INTELLIGENT FILE BREAKDOWN

## ��� YOUR MISSION

You are an expert backend architect. Analyze large controller files, identify single-purpose functions, extract them into focused modules, and create a clean, maintainable structure. **Work incrementally and test after each extraction.**

---

## ��� INTELLIGENT ANALYSIS APPROACH

### STEP 1: ANALYZE BEFORE YOU ACT

Before touching any code, analyze each large file:

```javascript
// For each function in userController.js, ask:
1. What is this function's SINGLE responsibility?
2. What domain does it belong to? (auth, profile, admin, collections, etc.)
3. What dependencies does it have?
4. What business logic can be extracted to services?
5. Can this be grouped with similar functions?
```

### STEP 2: SMART CATEGORIZATION

Group functions by their **primary purpose**:

```javascript
// Example analysis of userController.js functions:

AUTH_FUNCTIONS = [
  'authUser',        // → src/controllers/auth/authController.js
  'registerUser',    // → src/controllers/auth/authController.js  
  'logoutUser'       // → src/controllers/auth/authController.js
]

PROFILE_FUNCTIONS = [
  'getUserProfile',     // → src/controllers/user/profileController.js
  'updateUserProfile',  // → src/controllers/user/profileController.js
  'uploadProfileImage'  // → src/controllers/user/profileController.js
]

ADMIN_FUNCTIONS = [
  'getUsers',          // → src/controllers/user/adminController.js
  'deleteUser',        // → src/controllers/user/adminController.js
  'getUserById'        // → src/controllers/user/adminController.js
]

COLLECTION_FUNCTIONS = [
  'getUserAssignedCollections',  // → src/controllers/user/userCollectionController.js
  'adminAssignCollection',       // → src/controllers/user/userCollectionController.js
  'trackCollectionAccess'        // → src/controllers/user/userCollectionController.js
]
```

---

## ⚡ EXECUTION STRATEGY

### PHASE 1: ONE DOMAIN AT A TIME

**Start with AUTH (simplest and most isolated):**

#### 1.1 Create Target Structure
```bash
mkdir -p src/controllers/auth
mkdir -p src/services
mkdir -p src/routes/v1
```

#### 1.2 Extract Auth Functions
```javascript
// STEP 1: Create src/controllers/auth/authController.js
import asyncHandler from '../../../middleware/asyncHandler.js';
import { AuthService } from '../../services/authService.js';

class AuthController {
  // Copy authUser function EXACTLY, but delegate logic to service
  static login = asyncHandler(async (req, res) => {
    const { email, password } = req.body;
    const result = await AuthService.authenticateUser(email, password);
    res.json(result);
  });

  static register = asyncHandler(async (req, res) => {
    const { name, email, password } = req.body;
    const result = await AuthService.registerUser({ name, email, password });
    res.status(201).json(result);
  });

  static logout = asyncHandler(async (req, res) => {
    res.clearCookie('jwt');
    res.status(200).json({ message: 'Logged out successfully' });
  });
}

export default AuthController;
```

#### 1.3 Extract Business Logic to Service
```javascript
// STEP 2: Create src/services/authService.js
import generateToken from '../../utils/generateToken.js';
import User from '../../models/userModel.js';

export class AuthService {
  static async authenticateUser(email, password) {
    // Move ALL business logic here from the original controller function
    const user = await User.findOne({ email });

    if (user && (await user.matchPassword(password))) {
      // Update login tracking
      user.lastLogin = new Date();
      user.loginCount = (user.loginCount || 0) + 1;
      await user.save();

      const token = generateToken(user._id);
      
      return {
        _id: user._id,
        name: user.name,
        email: user.email,
        isAdmin: user.isAdmin,
        token
      };
    } else {
      throw new Error('Invalid email or password');
    }
  }

  static async registerUser({ name, email, password }) {
    // Move ALL registration logic here
    const userExists = await User.findOne({ email });
    if (userExists) {
      throw new Error('User already exists');
    }

    const user = await User.create({
      name,
      email,
      password,
    });

    const token = generateToken(user._id);
    
    return {
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
      token
    };
  }
}
```

#### 1.4 Create Routes
```javascript
// STEP 3: Create src/routes/v1/authRoutes.js
import express from 'express';
import AuthController from '../../controllers/auth/authController.js';

const router = express.Router();

router.post('/login', AuthController.login);
router.post('/register', AuthController.register);
router.post('/logout', AuthController.logout);

export default router;
```

#### 1.5 Update Server (ADD, don't replace)
```javascript
// STEP 4: Add to server.js
import authRoutes from './src/routes/v1/authRoutes.js';

// Add ALONGSIDE existing routes
app.use('/api/v1/auth', authRoutes);
app.use('/api', userRoutes); // Keep existing
```

#### 1.6 Test New Routes Work
```bash
# Test new endpoints work
curl -X POST http://localhost:5000/api/v1/auth/login -d '{"email":"test@test.com","password":"test123"}' -H "Content-Type: application/json"

# Test old endpoints still work  
curl -X POST http://localhost:5000/api/users/auth -d '{"email":"test@test.com","password":"test123"}' -H "Content-Type: application/json"
```

#### 1.7 Update Original Controller (Only after testing)
```javascript
// STEP 5: Replace functions in controllers/userController.js
import AuthController from '../src/controllers/auth/authController.js';

// Replace the old functions with calls to new controller
const authUser = AuthController.login;
const registerUser = AuthController.register;
const logoutUser = AuthController.logout;

// OR completely remove them and update routes to use new controller
```

---

### PHASE 2: PROFILE FUNCTIONS

**Apply same pattern to profile functions:**

#### 2.1 Analyze Profile Functions
```javascript
// Identify all profile-related functions:
- getUserProfile
- updateUserProfile  
- refreshUserData
- uploadProfileImage (if exists)
```

#### 2.2 Create Profile Structure
```javascript
// src/controllers/user/profileController.js
class ProfileController {
  static getProfile = asyncHandler(async (req, res) => {
    const profile = await UserService.getUserProfile(req.user._id);
    res.json(profile);
  });

  static updateProfile = asyncHandler(async (req, res) => {
    const updatedProfile = await UserService.updateUserProfile(req.user._id, req.body);
    res.json(updatedProfile);
  });
}

// src/services/userService.js
export class UserService {
  static async getUserProfile(userId) {
    // Extract ALL profile logic from original controller
  }

  static async updateUserProfile(userId, updateData) {
    // Extract ALL update logic from original controller
  }
}
```

---

### PHASE 3: COLLECTION FUNCTIONS

**Apply same pattern to collection functions:**

#### 3.1 Break Down by Responsibility
```javascript
// Basic CRUD → src/controllers/collection/collectionController.js
- getCollections
- getCollectionById  
- createCollection
- updateCollection
- deleteCollection

// Admin Operations → src/controllers/collection/adminController.js
- getAdminCollections
- updateCollectionOrder
- normalizeCollectionOrders

// Sub-Collections → src/controllers/collection/subCollectionController.js
- getSubCollections
- createSubCollection
- updateSubCollection
- deleteSubCollection

// User-Collection Relationship → src/controllers/user/userCollectionController.js
- getUserAssignedCollections
- adminAssignCollection
- trackCollectionAccess
```

---

## ��� SMART EXTRACTION RULES

### RULE 1: Single Responsibility Principle
```javascript
// If a function does multiple things, split it:

// BAD: One function doing everything
const updateUserProfile = (req, res) => {
  // Validate input
  // Update user data  
  // Upload image
  // Send notification
  // Log activity
  // Return response
};

// GOOD: Split into focused functions
const updateProfile = (req, res) => {
  const result = UserService.updateProfile(req.user._id, req.body);
  res.json(result);
};

// Business logic in service
UserService.updateProfile = (userId, data) => {
  ValidationService.validateProfileData(data);
  const updated = UserRepository.updateUser(userId, data);
  NotificationService.sendProfileUpdateNotification(userId);
  ActivityService.logProfileUpdate(userId);
  return updated;
};
```

### RULE 2: Extract Common Logic
```javascript
// If you see repeated patterns, extract them:

// Create src/services/shared/validationService.js
export class ValidationService {
  static validateEmail(email) {
    // Common email validation
  }
  
  static validateObjectId(id) {
    // Common MongoDB ObjectId validation
  }
}

// Create src/services/shared/responseService.js
export class ResponseService {
  static success(res, data, message = 'Success') {
    res.json({ success: true, data, message });
  }
  
  static error(res, error, statusCode = 400) {
    res.status(statusCode).json({ success: false, error: error.message });
  }
}
```

### RULE 3: Proper Import Management
```javascript
// Each new file should have ALL its dependencies:

// src/controllers/auth/authController.js
import asyncHandler from '../../../middleware/asyncHandler.js';
import { AuthService } from '../../services/authService.js';
import { ValidationService } from '../../services/shared/validationService.js';
import { ResponseService } from '../../services/shared/responseService.js';

// src/services/authService.js  
import bcrypt from 'bcryptjs';
import generateToken from '../../utils/generateToken.js';
import User from '../../models/userModel.js';
import { ValidationService } from './shared/validationService.js';
```

---

## ��� TESTING STRATEGY

### After Each Extraction:

```bash
# 1. Run existing tests
npm test

# 2. Test specific endpoints
curl -X POST http://localhost:5000/api/v1/auth/login -d '{"email":"test@test.com","password":"test123"}' -H "Content-Type: application/json"

# 3. Verify old endpoints still work
curl -X POST http://localhost:5000/api/users/auth -d '{"email":"test@test.com","password":"test123"}' -H "Content-Type: application/json"

# 4. Check server starts without errors
npm start
```

---

## ��� CRITICAL SAFETY RULES

### BEFORE YOU START:
```bash
# Create backup branch
git checkout -b ai-refactoring-backup
git add .
git commit -m "Before AI refactoring"

# Create working branch  
git checkout -b ai-refactoring-work
```

### DURING REFACTORING:
1. **Extract ONE domain at a time** (auth → profile → collections)
2. **Test after each extraction**
3. **Keep old code until new code is proven to work**
4. **Import all dependencies in new files**
5. **Never proceed if tests fail**

### IF SOMETHING BREAKS:
```bash
# Immediate rollback
git checkout ai-refactoring-backup
git branch -D ai-refactoring-work

# Or restore specific file
git checkout HEAD~1 -- controllers/userController.js
```

---

## ��� SUCCESS CHECKLIST

After each phase, verify:

- [ ] New files created with proper structure
- [ ] All imports working correctly
- [ ] Business logic extracted to services
- [ ] Both old and new endpoints functional
- [ ] Tests passing
- [ ] Server starts without errors
- [ ] No duplicate code between old and new files
- [ ] File sizes under 400 lines each

---

## ��� EXPECTED OUTCOME

Transform this:
```
controllers/
├── userController.js (1,898 lines) ❌
└── collectionController.js (1,074 lines) ❌
```

Into this:
```
src/
├── controllers/
│   ├── auth/
│   │   └── authController.js (150 lines) ✅
│   ├── user/
│   │   ├── profileController.js (200 lines) ✅
│   │   ├── adminController.js (250 lines) ✅
│   │   └── userCollectionController.js (300 lines) ✅
│   └── collection/
│       ├── collectionController.js (300 lines) ✅
│       ├── adminController.js (200 lines) ✅
│       └── subCollectionController.js (200 lines) ✅
├── services/
│   ├── authService.js (180 lines) ✅
│   ├── userService.js (250 lines) ✅
│   ├── collectionService.js (200 lines) ✅
│   └── shared/
│       ├── validationService.js (100 lines) ✅
│       └── responseService.js (80 lines) ✅
└── routes/
    └── v1/
        ├── authRoutes.js (50 lines) ✅
        ├── userRoutes.js (80 lines) ✅
        └── collectionRoutes.js (60 lines) ✅
```

---

## ��� START COMMAND

**Begin with Phase 1 (Auth extraction) only. After successful completion, I will give you Phase 2 instructions.**

**Your first task: Analyze `controllers/userController.js` and extract all authentication-related functions following the exact pattern above.**

**Remember: Work incrementally, test everything, and maintain 100% functionality.**
