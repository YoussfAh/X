# COMPLETE BACKEND RECREATION GUIDE

## OVERVIEW
This guide provides step-by-step instructions to recreate the GrindX backend system from scratch. Follow these instructions exactly to avoid errors.

---

## PREREQUISITES

### Required Software
```bash
# Install Node.js (v18+ recommended)
# Download from: https://nodejs.org/

# Verify installation
node --version  # Should be v18.0.0 or higher
npm --version   # Should be 8.0.0 or higher
```

### Required Accounts & Services
1. **MongoDB Atlas Account** - https://www.mongodb.com/atlas
2. **Cloudinary Account** - https://cloudinary.com/
3. **PayPal Developer Account** - https://developer.paypal.com/
4. **Vercel Account** (for deployment) - https://vercel.com/

---

## STEP 1: PROJECT INITIALIZATION

### Create Project Structure
```bash
mkdir grindx-backend
cd grindx-backend

# Initialize npm project
npm init -y

# Create directory structure
mkdir -p config controllers models routes middleware utils uploads data
mkdir -p tests/unit tests/integration tests/e2e
```

### Install Dependencies
```bash
# Production dependencies
npm install express@^4.18.2
npm install mongoose@^7.0.1
npm install bcryptjs@^2.4.3
npm install jsonwebtoken@^9.0.0
npm install cookie-parser@^1.4.6
npm install cors@^2.8.5
npm install dotenv@^16.0.3
npm install cloudinary@^1.41.3
npm install multer@^1.4.5-lts.1
npm install colors@^1.4.0
npm install uuid@^11.1.0

# Development dependencies
npm install --save-dev nodemon@^2.0.21
npm install --save-dev @types/express@^4.17.17
npm install --save-dev jest@^29.0.0
npm install --save-dev supertest@^6.3.0
npm install --save-dev mongodb-memory-server@^8.0.0
```

### Update package.json
```json
{
  "name": "grindx-backend",
  "version": "2.0.0",
  "type": "module",
  "description": "Backend for the GrindX application",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js",
    "test": "jest",
    "test:watch": "jest --watch",
    "test:coverage": "jest --coverage",
    "data:import": "node seeder",
    "data:destroy": "node seeder -d"
  },
  "dependencies": {
    "bcryptjs": "^2.4.3",
    "cloudinary": "^1.41.3",
    "colors": "^1.4.0",
    "cookie-parser": "^1.4.6",
    "cors": "^2.8.5",
    "dotenv": "^16.0.3",
    "express": "^4.18.2",
    "jsonwebtoken": "^9.0.0",
    "mongoose": "^7.0.1",
    "multer": "^1.4.5-lts.1",
    "uuid": "^11.1.0"
  },
  "devDependencies": {
    "@types/express": "^4.17.17",
    "jest": "^29.0.0",
    "mongodb-memory-server": "^8.0.0",
    "nodemon": "^2.0.21",
    "supertest": "^6.3.0"
  }
}
```

---

## STEP 2: ENVIRONMENT CONFIGURATION

### Create .env file
```bash
# Create environment file
touch .env

# Add to .env (replace with your actual values):
NODE_ENV=development
PORT=5000

# Database
MONGO_URI=mongodb+srv://username:password@cluster.mongodb.net/grindx

# JWT Secret (generate a strong secret)
JWT_SECRET=your_super_secret_jwt_key_here

# Cloudinary Configuration
CLOUDINARY_CLOUD_NAME=your_cloudinary_cloud_name
CLOUDINARY_API_KEY=your_cloudinary_api_key
CLOUDINARY_API_SECRET=your_cloudinary_api_secret

# PayPal Configuration
PAYPAL_CLIENT_ID=your_paypal_client_id
PAYPAL_CLIENT_SECRET=your_paypal_client_secret

# Frontend URL (for CORS)
FRONTEND_URL=http://localhost:3000

# Vercel Configuration (for deployment)
VERCEL=0
```

### Create .gitignore
```bash
# Create .gitignore file
cat > .gitignore << EOF
node_modules/
.env
.env.local
.env.production
npm-debug.log*
yarn-debug.log*
yarn-error.log*
.vercel
uploads/*
!uploads/.gitkeep
.DS_Store
*.log
EOF
```

---

## STEP 3: DATABASE CONFIGURATION

### Create config/db.js
```javascript
import mongoose from 'mongoose';

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI);
    console.log(`MongoDB Connected: ${conn.connection.host}`);
    return conn;
  } catch (error) {
    console.error(`MongoDB Connection Error: ${error.message}`);
    // Don't exit the process on Vercel
    if (process.env.VERCEL !== '1') {
      // Only exit in development, not in production
      if (process.env.NODE_ENV === 'development') {
        process.exit(1);
      }
    }
    throw error; // Throw the error so we can handle it in the server.js
  }
};

export default connectDB;
```

---

## STEP 4: MIDDLEWARE SETUP

### Create middleware/asyncHandler.js
```javascript
const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

export default asyncHandler;
```

### Create middleware/errorMiddleware.js
```javascript
const notFound = (req, res, next) => {
  const error = new Error(`Not Found - ${req.originalUrl}`);
  res.status(404);
  next(error);
};

const errorHandler = (err, req, res, next) => {
  let statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  let message = err.message;

  res.status(statusCode).json({
    message: message,
    stack: process.env.NODE_ENV === 'production' ? null : err.stack,
  });
};

export { notFound, errorHandler };
```

### Create middleware/authMiddleware.js
```javascript
import jwt from 'jsonwebtoken';
import asyncHandler from './asyncHandler.js';
import User from '../models/userModel.js';

// User must be authenticated
const protect = asyncHandler(async (req, res, next) => {
  let token;

  // Read JWT from the 'jwt' cookie
  token = req.cookies.jwt;

  if (token) {
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      req.user = await User.findById(decoded.userId).select('-password');

      next();
    } catch (error) {
      console.error(error);
      res.status(401);
      throw new Error('Not authorized, token failed');
    }
  } else {
    res.status(401);
    throw new Error('Not authorized, no token');
  }
});

// User must be an admin
const admin = (req, res, next) => {
  if (req.user && req.user.isAdmin) {
    next();
  } else {
    res.status(401);
    throw new Error('Not authorized as an admin');
  }
};

export { protect, admin };
```

### Create middleware/checkObjectId.js
```javascript
import { isValidObjectId } from 'mongoose';

function checkObjectId(req, res, next) {
  if (!isValidObjectId(req.params.id)) {
    res.status(404);
    throw new Error(`Invalid ObjectId of:  ${req.params.id}`);
  }
  next();
}

export default checkObjectId;
```

---

## STEP 5: UTILITY FUNCTIONS

### Create utils/generateToken.js
```javascript
import jwt from 'jsonwebtoken';

const generateToken = (res, userId) => {
  const token = jwt.sign({ userId }, process.env.JWT_SECRET, {
    expiresIn: '30d',
  });

  // Set JWT as an HTTP-Only cookie
  res.cookie('jwt', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV !== 'development', // Use secure cookies in production
    sameSite: 'strict', // Prevent CSRF attacks
    maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
  });
};

export default generateToken;
```

### Create utils/calcPrices.js
```javascript
function addDecimals(num) {
  return (Math.round(num * 100) / 100).toFixed(2);
}

function calcPrices(orderItems) {
  // Calculate the items price
  const itemsPrice = addDecimals(
    orderItems.reduce((acc, item) => acc + item.price * item.qty, 0)
  );
  
  // Calculate the shipping price
  const shippingPrice = addDecimals(itemsPrice > 100 ? 0 : 10);
  
  // Calculate the tax price
  const taxPrice = addDecimals(Number((0.15 * itemsPrice).toFixed(2)));
  
  // Calculate the total price
  const totalPrice = (
    Number(itemsPrice) +
    Number(shippingPrice) +
    Number(taxPrice)
  ).toFixed(2);

  return {
    itemsPrice,
    shippingPrice,
    taxPrice,
    totalPrice,
  };
}

export { addDecimals, calcPrices };
```

---

## STEP 6: DATABASE MODELS

### Create models/userModel.js (Simplified Version)
```javascript
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const userSchema = mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
    },
    isAdmin: {
      type: Boolean,
      required: true,
      default: false,
    },
    whatsAppPhoneNumber: {
      type: String,
      default: '',
    },
  },
  {
    timestamps: true,
  }
);

// Match user entered password to hashed password in database
userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

// Encrypt password using bcrypt
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) {
    next();
  }

  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
});

const User = mongoose.model('User', userSchema);

export default User;
```

### Create models/productModel.js
```javascript
import mongoose from 'mongoose';

const reviewSchema = mongoose.Schema(
  {
    name: { type: String, required: true },
    rating: { type: Number, required: true },
    comment: { type: String, required: true },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'User',
    },
  },
  {
    timestamps: true,
  }
);

const productSchema = mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'User',
    },
    name: {
      type: String,
      required: true,
    },
    image: {
      type: String,
      required: true,
    },
    category: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    reviews: [reviewSchema],
    rating: {
      type: Number,
      required: true,
      default: 0,
    },
    numReviews: {
      type: Number,
      required: true,
      default: 0,
    },
  },
  {
    timestamps: true,
  }
);

const Product = mongoose.model('Product', productSchema);

export default Product;
```

---

## STEP 7: CONTROLLERS (SIMPLIFIED STARTING VERSIONS)

### Create controllers/userController.js (Basic Version)
```javascript
import asyncHandler from '../middleware/asyncHandler.js';
import generateToken from '../utils/generateToken.js';
import User from '../models/userModel.js';

// @desc    Auth user & get token
// @route   POST /api/users/auth
// @access  Public
const authUser = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email });

  if (user && (await user.matchPassword(password))) {
    generateToken(res, user._id);

    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
    });
  } else {
    res.status(401);
    throw new Error('Invalid email or password');
  }
});

// @desc    Register a new user
// @route   POST /api/users
// @access  Public
const registerUser = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;

  const userExists = await User.findOne({ email });

  if (userExists) {
    res.status(400);
    throw new Error('User already exists');
  }

  const user = await User.create({
    name,
    email,
    password,
  });

  if (user) {
    generateToken(res, user._id);

    res.status(201).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
    });
  } else {
    res.status(400);
    throw new Error('Invalid user data');
  }
});

// @desc    Logout user / clear cookie
// @route   POST /api/users/logout
// @access  Public
const logoutUser = (req, res) => {
  res.clearCookie('jwt');
  res.status(200).json({ message: 'Logged out successfully' });
};

// @desc    Get user profile
// @route   GET /api/users/profile
// @access  Private
const getUserProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);

  if (user) {
    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
    });
  } else {
    res.status(404);
    throw new Error('User not found');
  }
});

export {
  authUser,
  registerUser,
  logoutUser,
  getUserProfile,
};
```

---

## STEP 8: ROUTES SETUP

### Create routes/userRoutes.js
```javascript
import express from 'express';
import {
  authUser,
  registerUser,
  logoutUser,
  getUserProfile,
} from '../controllers/userController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.route('/').post(registerUser);
router.post('/auth', authUser);
router.post('/logout', logoutUser);
router.route('/profile').get(protect, getUserProfile);

export default router;
```

---

## STEP 9: MAIN SERVER FILE

### Create server.js
```javascript
import path from 'path';
import express from 'express';
import dotenv from 'dotenv';
import cookieParser from 'cookie-parser';
import cors from 'cors';

// Load environment variables
dotenv.config();

import connectDB from './config/db.js';
import userRoutes from './routes/userRoutes.js';
import { notFound, errorHandler } from './middleware/errorMiddleware.js';

const port = process.env.PORT || 5000;

// Connect to database with error handling
try {
  connectDB().then(() => {
    console.log('MongoDB Connected');
  }).catch(err => {
    console.error(`MongoDB connection error: ${err.message}`);
  });
} catch (error) {
  console.error(`Error in database connection setup: ${error.message}`);
}

const app = express();

// CORS configuration
const whitelist = [
  'http://localhost:3000',
  'http://127.0.0.1:3000',
  process.env.FRONTEND_URL,
];

app.use(cors({
  origin: function (origin, callback) {
    // Allow requests with no origin (like mobile apps, curl requests)
    if (!origin) return callback(null, true);

    if (whitelist.indexOf(origin) !== -1 || process.env.NODE_ENV === 'development') {
      callback(null, true);
    } else {
      console.log(`CORS blocked origin: ${origin}`);
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true // Allow credentials (cookies)
}));

// Body parsing middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Routes
app.use('/api/users', userRoutes);

// Base API route
app.get('/', (req, res) => {
  res.send('API is running....');
});

// Error handling middleware
app.use(notFound);
app.use(errorHandler);

// For Vercel, we export the app instead of listening directly
if (process.env.NODE_ENV !== 'production') {
  app.listen(port, () =>
    console.log(`Server running in ${process.env.NODE_ENV} mode on port ${port}`)
  );
}

export default app;
```

---

## STEP 10: TESTING SETUP

### Create jest.config.js
```javascript
export default {
  testEnvironment: 'node',
  transform: {},
  extensionsToTreatAsEsm: ['.js'],
  moduleNameMapping: {
    '^(\\.{1,2}/.*)\\.js$': '$1'
  },
  testMatch: [
    '**/tests/**/*.test.js'
  ],
  collectCoverageFrom: [
    'controllers/**/*.js',
    'models/**/*.js',
    'utils/**/*.js',
    'middleware/**/*.js'
  ],
  coverageDirectory: 'coverage',
  coverageReporters: ['text', 'lcov', 'html']
};
```

### Create tests/setup.js
```javascript
import { MongoMemoryServer } from 'mongodb-memory-server';
import mongoose from 'mongoose';

let mongoServer;

// Setup function called before all tests
export const setupTestDB = async () => {
  mongoServer = await MongoMemoryServer.create();
  const mongoUri = mongoServer.getUri();
  
  await mongoose.connect(mongoUri);
};

// Cleanup function called after all tests
export const teardownTestDB = async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.connection.close();
  await mongoServer.stop();
};

// Clear database between tests
export const clearTestDB = async () => {
  const collections = mongoose.connection.collections;
  for (const key in collections) {
    const collection = collections[key];
    await collection.deleteMany({});
  }
};
```

### Create tests/unit/controllers/userController.test.js
```javascript
import request from 'supertest';
import app from '../../../server.js';
import User from '../../../models/userModel.js';
import { setupTestDB, teardownTestDB, clearTestDB } from '../../setup.js';

describe('User Controller', () => {
  beforeAll(async () => {
    await setupTestDB();
  });

  afterAll(async () => {
    await teardownTestDB();
  });

  beforeEach(async () => {
    await clearTestDB();
  });

  describe('POST /api/users/auth', () => {
    it('should authenticate valid user', async () => {
      // Create test user
      const testUser = {
        name: 'Test User',
        email: 'test@example.com',
        password: 'password123'
      };

      await User.create(testUser);

      const response = await request(app)
        .post('/api/users/auth')
        .send({
          email: testUser.email,
          password: testUser.password
        });

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('_id');
      expect(response.body.email).toBe(testUser.email);
    });

    it('should reject invalid credentials', async () => {
      const response = await request(app)
        .post('/api/users/auth')
        .send({
          email: 'invalid@example.com',
          password: 'wrongpassword'
        });

      expect(response.status).toBe(401);
    });
  });

  describe('POST /api/users', () => {
    it('should register new user', async () => {
      const testUser = {
        name: 'New User',
        email: 'new@example.com',
        password: 'password123'
      };

      const response = await request(app)
        .post('/api/users')
        .send(testUser);

      expect(response.status).toBe(201);
      expect(response.body.email).toBe(testUser.email);
    });

    it('should not register user with existing email', async () => {
      const testUser = {
        name: 'Test User',
        email: 'existing@example.com',
        password: 'password123'
      };

      // Create user first
      await User.create(testUser);

      const response = await request(app)
        .post('/api/users')
        .send(testUser);

      expect(response.status).toBe(400);
    });
  });
});
```

---

## STEP 11: DEPLOYMENT SETUP

### Create vercel.json
```json
{
  "version": 2,
  "builds": [
    {
      "src": "server.js",
      "use": "@vercel/node"
    }
  ],
  "routes": [
    {
      "src": "/(.*)",
      "dest": "/server.js"
    }
  ],
  "env": {
    "NODE_ENV": "production"
  }
}
```

---

## STEP 12: VERIFICATION & TESTING

### Start Development Server
```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

### Test Basic Functionality
```bash
# Test health endpoint
curl http://localhost:5000/

# Test user registration
curl -X POST http://localhost:5000/api/users \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test User",
    "email": "test@example.com",
    "password": "password123"
  }'

# Run tests
npm test
```

---

## STEP 13: DATABASE INDEXES (IMPORTANT)

### Create database/indexes.js
```javascript
import mongoose from 'mongoose';

export const createIndexes = async () => {
  try {
    // User indexes
    await mongoose.connection.collection('users').createIndex(
      { email: 1 }, 
      { unique: true }
    );
    
    console.log('✅ Database indexes created successfully');
  } catch (error) {
    console.error('❌ Error creating indexes:', error);
  }
};
```

### Add to server.js after DB connection
```javascript
import { createIndexes } from './database/indexes.js';

// After successful DB connection
connectDB().then(async () => {
  console.log('MongoDB Connected');
  await createIndexes();
}).catch(err => {
  console.error(`MongoDB connection error: ${err.message}`);
});
```

---

## STEP 14: FINAL VERIFICATION

### Project Structure Check
```
grindx-backend/
├── config/
│   └── db.js
├── controllers/
│   └── userController.js
├── middleware/
│   ├── asyncHandler.js
│   ├── authMiddleware.js
│   ├── checkObjectId.js
│   └── errorMiddleware.js
├── models/
│   ├── userModel.js
│   └── productModel.js
├── routes/
│   └── userRoutes.js
├── tests/
│   ├── setup.js
│   └── unit/
├── utils/
│   ├── generateToken.js
│   └── calcPrices.js
├── .env
├── .gitignore
├── jest.config.js
├── package.json
├── server.js
└── vercel.json
```

### Final Tests
```bash
# Run all tests
npm test

# Check test coverage
npm run test:coverage

# Start server and verify endpoints
npm run dev
```

---

## TROUBLESHOOTING

### Common Issues

#### 1. MongoDB Connection Error
```bash
# Check environment variables
echo $MONGO_URI

# Test connection string in MongoDB Compass
# Ensure IP whitelist includes your IP
```

#### 2. JWT Secret Error
```bash
# Generate strong JWT secret
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

#### 3. CORS Issues
```bash
# Check FRONTEND_URL in .env
# Verify whitelist in server.js
```

#### 4. Module Import Errors
```bash
# Ensure "type": "module" in package.json
# Use .js extensions in imports
```

### Testing Database Connection
```javascript
// Create test script: test-db.js
import connectDB from './config/db.js';
import dotenv from 'dotenv';

dotenv.config();

const testConnection = async () => {
  try {
    await connectDB();
    console.log('✅ Database connection successful');
    process.exit(0);
  } catch (error) {
    console.error('❌ Database connection failed:', error);
    process.exit(1);
  }
};

testConnection();
```

---

## SUCCESS CHECKLIST

- [ ] All dependencies installed
- [ ] Environment variables configured
- [ ] Database connection working
- [ ] Basic user endpoints functional
- [ ] Tests passing
- [ ] Development server starting
- [ ] Authentication working
- [ ] CORS configured properly
- [ ] Error handling working
- [ ] Database indexes created

This guide creates a solid foundation that can be safely extended without breaking existing functionality. 