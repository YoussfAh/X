# COMPLETE BACKEND RECREATION GUIDE

## OVERVIEW
Step-by-step guide to recreate the GrindX backend system from scratch.

## PREREQUISITES

### Required Software
- Node.js v18+
- npm or yarn
- Git
- MongoDB Compass (optional)

### Required Accounts
- MongoDB Atlas account
- Cloudinary account  
- PayPal Developer account
- Vercel account (for deployment)

---

## STEP 1: PROJECT INITIALIZATION

### Create Project
```bash
mkdir grindx-backend
cd grindx-backend
npm init -y
```

### Install Dependencies
```bash
# Production dependencies
npm install express@^4.18.2 mongoose@^7.0.1 bcryptjs@^2.4.3
npm install jsonwebtoken@^9.0.0 cookie-parser@^1.4.6 cors@^2.8.5
npm install dotenv@^16.0.3 cloudinary@^1.41.3 multer@^1.4.5-lts.1
npm install colors@^1.4.0 uuid@^11.1.0

# Development dependencies
npm install --save-dev nodemon@^2.0.21 @types/express@^4.17.17
npm install --save-dev jest@^29.0.0 supertest@^6.3.0
```

### Create Directory Structure
```bash
mkdir -p config controllers models routes middleware utils uploads data tests
```

---

## STEP 2: ENVIRONMENT SETUP

### Create .env file
```
NODE_ENV=development
PORT=5000
MONGO_URI=your_mongodb_connection_string
JWT_SECRET=your_jwt_secret_here
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
PAYPAL_CLIENT_ID=your_paypal_client_id
FRONTEND_URL=http://localhost:3000
```

### Create .gitignore
```
node_modules/
.env
.env.local
uploads/*
!uploads/.gitkeep
*.log
.DS_Store
```

---

## STEP 3: BASIC CONFIGURATION

### Database Connection (config/db.js)
```javascript
import mongoose from 'mongoose';

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI);
    console.log(`MongoDB Connected: ${conn.connection.host}`);
    return conn;
  } catch (error) {
    console.error(`MongoDB Connection Error: ${error.message}`);
    if (process.env.NODE_ENV === 'development') {
      process.exit(1);
    }
    throw error;
  }
};

export default connectDB;
```

### Error Middleware (middleware/errorMiddleware.js)
```javascript
const notFound = (req, res, next) => {
  const error = new Error(`Not Found - ${req.originalUrl}`);
  res.status(404);
  next(error);
};

const errorHandler = (err, req, res, next) => {
  let statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  let message = err.message;

  res.status(statusCode).json({
    message: message,
    stack: process.env.NODE_ENV === 'production' ? null : err.stack,
  });
};

export { notFound, errorHandler };
```

---

## STEP 4: AUTHENTICATION SETUP

### JWT Token Utility (utils/generateToken.js)
```javascript
import jwt from 'jsonwebtoken';

const generateToken = (res, userId) => {
  const token = jwt.sign({ userId }, process.env.JWT_SECRET, {
    expiresIn: '30d',
  });

  res.cookie('jwt', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV !== 'development',
    sameSite: 'strict',
    maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
  });
};

export default generateToken;
```

### Auth Middleware (middleware/authMiddleware.js)
```javascript
import jwt from 'jsonwebtoken';
import asyncHandler from './asyncHandler.js';
import User from '../models/userModel.js';

const protect = asyncHandler(async (req, res, next) => {
  let token = req.cookies.jwt;

  if (token) {
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded.userId).select('-password');
      next();
    } catch (error) {
      res.status(401);
      throw new Error('Not authorized, token failed');
    }
  } else {
    res.status(401);
    throw new Error('Not authorized, no token');
  }
});

const admin = (req, res, next) => {
  if (req.user && req.user.isAdmin) {
    next();
  } else {
    res.status(401);
    throw new Error('Not authorized as an admin');
  }
};

export { protect, admin };
```

---

## STEP 5: USER MODEL

### User Model (models/userModel.js)
```javascript
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const userSchema = mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    isAdmin: { type: Boolean, default: false },
    whatsAppPhoneNumber: { type: String, default: '' }
  },
  { timestamps: true }
);

userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) {
    next();
  }
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
});

const User = mongoose.model('User', userSchema);
export default User;
```

---

## STEP 6: MAIN SERVER

### Server File (server.js)
```javascript
import express from 'express';
import dotenv from 'dotenv';
import cookieParser from 'cookie-parser';
import cors from 'cors';

dotenv.config();

import connectDB from './config/db.js';
import { notFound, errorHandler } from './middleware/errorMiddleware.js';

const port = process.env.PORT || 5000;

// Connect to database
connectDB();

const app = express();

// CORS configuration
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true
}));

// Body parsing middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Base route
app.get('/', (req, res) => {
  res.send('GrindX API is running...');
});

// Error handling
app.use(notFound);
app.use(errorHandler);

// Start server
if (process.env.NODE_ENV !== 'production') {
  app.listen(port, () =>
    console.log(`Server running on port ${port}`)
  );
}

export default app;
```

---

## STEP 7: TESTING SETUP

### Package.json Scripts
```json
{
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js",
    "test": "jest",
    "test:watch": "jest --watch"
  }
}
```

### Basic Test (tests/basic.test.js)
```javascript
import request from 'supertest';
import app from '../server.js';

describe('Basic API Tests', () => {
  test('GET / should return success message', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('API is running');
  });
});
```

---

## STEP 8: VERIFICATION

### Start Development Server
```bash
npm run dev
```

### Test Basic Functionality
```bash
# Test health endpoint
curl http://localhost:5000/

# Should return: "GrindX API is running..."
```

### Run Tests
```bash
npm test
```

---

## NEXT STEPS

After this basic setup works:

1. Add user authentication endpoints
2. Add collection management
3. Add product catalog
4. Add one-time code system
5. Add testing for each feature
6. Deploy to Vercel

This foundation provides a safe starting point that can be extended without breaking existing functionality.

## TROUBLESHOOTING

### Common Issues

**MongoDB Connection Error:**
- Check MONGO_URI in .env
- Verify MongoDB Atlas IP whitelist
- Test connection string in MongoDB Compass

**Module Import Errors:**
- Ensure `"type": "module"` in package.json
- Use .js extensions in imports

**CORS Issues:**
- Check FRONTEND_URL in .env
- Verify origin in CORS configuration

This guide creates a minimal but functional backend that can be safely extended. 