# CONTROLLER REFACTORING DIAGRAM

## OVERVIEW
This diagram shows the decomposition strategy for oversized controllers, breaking them into smaller, focused modules with clear responsibilities.

## CURRENT CONTROLLER PROBLEMS

```mermaid
graph TB
    subgraph "CURRENT OVERSIZED CONTROLLERS"
        UC[userController.js<br/>1,898 LINES<br/>🔴 CRITICAL ISSUE]
        CC[collectionController.js<br/>1,074 LINES<br/>🟡 NEEDS SPLIT]
        OTCC[oneTimeCodeController.js<br/>480 LINES<br/>🟠 MANAGEABLE]
    end

    subgraph "PROBLEMS WITH CURRENT STRUCTURE"
        P1[Single Responsibility Principle Violated]
        P2[Hard to Test Individual Functions]
        P3[Merge Conflicts in Team Development]
        P4[Poor Code Navigation]
        P5[Mixed Business Logic & HTTP Handling]
        P6[Difficult Error Tracking]
    end

    UC --> P1
    UC --> P2
    UC --> P3
    CC --> P1
    CC --> P4
    CC --> P5
    OTCC --> P6

    classDef critical fill:#ff6b6b,stroke:#d63031,stroke-width:3px,color:#fff
    classDef warning fill:#fdcb6e,stroke:#e17055,stroke-width:2px
    classDef problem fill:#fd79a8,stroke:#e84393,stroke-width:2px,color:#fff

    class UC critical
    class CC warning
    class P1,P2,P3,P4,P5,P6 problem
```

## USER CONTROLLER DECOMPOSITION (1,898 → 4 Controllers)

```mermaid
graph TB
    subgraph "CURRENT: userController.js (1,898 lines)"
        CURRENT[userController.js<br/>🔴 MONOLITHIC CONTROLLER<br/><br/>✅ Authentication (5 functions)<br/>✅ Profile Management (4 functions)<br/>✅ Admin Operations (8 functions)<br/>✅ Collection Management (12 functions)<br/>✅ Contact Tracking (6 functions)<br/>✅ Time Frame Management (4 functions)<br/>✅ Device Management (3 functions)<br/>✅ WhatsApp Integration (5 functions)<br/>✅ Image Upload (2 functions)<br/>✅ Analytics (3 functions)]
    end

    subgraph "PROPOSED: Split into 4 Controllers"
        AUTH[authController.js<br/>~200 lines<br/>🟢 FOCUSED<br/><br/>• authUser<br/>• registerUser<br/>• logoutUser<br/>• refreshToken<br/>• forgotPassword]
        
        PROFILE[profileController.js<br/>~300 lines<br/>🟢 FOCUSED<br/><br/>• getUserProfile<br/>• updateUserProfile<br/>• uploadProfileImage<br/>• deleteAccount<br/>• getProfileAnalytics]
        
        ADMIN[adminUserController.js<br/>~400 lines<br/>🟢 FOCUSED<br/><br/>• getUsers<br/>• getUserById<br/>• updateUser<br/>• deleteUser<br/>• toggleUserStatus<br/>• setUserRole<br/>• getUserAnalytics<br/>• bulkUserOperations]
        
        COLLECTION[userCollectionController.js<br/>~600 lines<br/>🟢 FOCUSED<br/><br/>• getUserCollections<br/>• assignCollection<br/>• removeCollection<br/>• trackAccess<br/>• updateProgress<br/>• getAccessHistory<br/>• manageTimeFrames<br/>• handleWhatsAppSync<br/>• getCollectionAnalytics]
    end

    subgraph "REMAINING: Core User Logic"
        CORE[userController.js<br/>~400 lines<br/>🟢 CORE ONLY<br/><br/>• Complex business logic<br/>• Cross-system integrations<br/>• Advanced user operations<br/>• System-level functions]
    end

    CURRENT --> AUTH
    CURRENT --> PROFILE
    CURRENT --> ADMIN
    CURRENT --> COLLECTION
    CURRENT --> CORE

    classDef current fill:#ff6b6b,stroke:#d63031,stroke-width:3px,color:#fff
    classDef proposed fill:#00b894,stroke:#00a085,stroke-width:2px,color:#fff

    class CURRENT current
    class AUTH,PROFILE,ADMIN,COLLECTION,CORE proposed
```

## COLLECTION CONTROLLER DECOMPOSITION (1,074 → 3 Controllers)

```mermaid
graph TB
    subgraph "CURRENT: collectionController.js (1,074 lines)"
        CC_CURRENT[collectionController.js<br/>🟡 OVERSIZED CONTROLLER<br/><br/>✅ CRUD Operations (8 functions)<br/>✅ Admin Management (6 functions)<br/>✅ Sub-collection Handling (5 functions)<br/>✅ Product Management (4 functions)<br/>✅ Analytics & Reports (3 functions)<br/>✅ Bulk Operations (4 functions)<br/>✅ Access Control (3 functions)]
    end

    subgraph "PROPOSED: Split into 3 Controllers"
        CRUD[collectionCRUDController.js<br/>~400 lines<br/>🟢 BASIC OPERATIONS<br/><br/>• getCollections<br/>• getCollectionById<br/>• createCollection<br/>• updateCollection<br/>• deleteCollection<br/>• validateCollection<br/>• searchCollections<br/>• getCollectionProducts]
        
        ADMIN_COL[collectionAdminController.js<br/>~300 lines<br/>🟢 ADMIN OPERATIONS<br/><br/>• bulkCreateCollections<br/>• bulkUpdateCollections<br/>• bulkDeleteCollections<br/>• getCollectionAnalytics<br/>• manageCollectionAccess<br/>• exportCollectionData]
        
        SUBCOL[subCollectionController.js<br/>~374 lines<br/>🟢 HIERARCHY MANAGEMENT<br/><br/>• getSubCollections<br/>• createSubCollection<br/>• moveCollection<br/>• getCollectionHierarchy<br/>• updateCollectionOrder<br/>• validateHierarchy]
    end

    CC_CURRENT --> CRUD
    CC_CURRENT --> ADMIN_COL
    CC_CURRENT --> SUBCOL

    classDef current fill:#fdcb6e,stroke:#e17055,stroke-width:2px
    classDef proposed fill:#00b894,stroke:#00a085,stroke-width:2px,color:#fff

    class CC_CURRENT current
    class CRUD,ADMIN_COL,SUBCOL proposed
```

## REFACTORING PROCESS FLOW

```mermaid
graph TD
    subgraph "PHASE 1: PREPARATION"
        A1[Create Backup Branch]
        A2[Add Testing Framework]
        A3[Write Baseline Tests]
        A4[Document Current API]
    end

    subgraph "PHASE 2: CREATE NEW CONTROLLERS"
        B1[Create authController.js]
        B2[Create authRoutes.js]
        B3[Test Auth Endpoints]
        B4[Create profileController.js]
        B5[Create profileRoutes.js]
        B6[Test Profile Endpoints]
        B7[Create adminUserController.js]
        B8[Create adminRoutes.js]
        B9[Test Admin Endpoints]
    end

    subgraph "PHASE 3: GRADUAL MIGRATION"
        C1[Update Route Imports One by One]
        C2[Test Each Migration Step]
        C3[Update Frontend API Calls]
        C4[Validate All Endpoints Work]
    end

    subgraph "PHASE 4: CLEANUP"
        D1[Comment Out Old Functions]
        D2[Remove Unused Imports]
        D3[Update Documentation]
        D4[Final Testing]
    end

    A1 --> A2 --> A3 --> A4
    A4 --> B1 --> B2 --> B3
    B3 --> B4 --> B5 --> B6
    B6 --> B7 --> B8 --> B9
    B9 --> C1 --> C2 --> C3 --> C4
    C4 --> D1 --> D2 --> D3 --> D4

    classDef phase1 fill:#e8f5e8,stroke:#4caf50,stroke-width:2px
    classDef phase2 fill:#e3f2fd,stroke:#2196f3,stroke-width:2px
    classDef phase3 fill:#fff3e0,stroke:#ff9800,stroke-width:2px
    classDef phase4 fill:#f3e5f5,stroke:#9c27b0,stroke-width:2px

    class A1,A2,A3,A4 phase1
    class B1,B2,B3,B4,B5,B6,B7,B8,B9 phase2
    class C1,C2,C3,C4 phase3
    class D1,D2,D3,D4 phase4
```

## DETAILED FUNCTION MAPPING

```mermaid
graph LR
    subgraph "userController.js Functions"
        UC_F1[authUser]
        UC_F2[registerUser]
        UC_F3[logoutUser]
        UC_F4[getUserProfile]
        UC_F5[updateUserProfile]
        UC_F6[getUsers]
        UC_F7[deleteUser]
        UC_F8[getUserCollections]
        UC_F9[assignCollection]
        UC_F10[trackCollectionAccess]
        UC_F11[uploadProfileImage]
        UC_F12[resetPassword]
        UC_F13[verifyEmail]
        UC_F14[manageTimeFrames]
        UC_F15[getContactHistory]
    end

    subgraph "New Controller Distribution"
        subgraph "authController.js"
            AUTH_F1[authUser]
            AUTH_F2[registerUser]
            AUTH_F3[logoutUser]
            AUTH_F4[refreshToken]
            AUTH_F5[forgotPassword]
        end

        subgraph "profileController.js"
            PROF_F1[getUserProfile]
            PROF_F2[updateUserProfile]
            PROF_F3[uploadProfileImage]
            PROF_F4[deleteAccount]
            PROF_F5[verifyEmail]
        end

        subgraph "adminUserController.js"
            ADMIN_F1[getUsers]
            ADMIN_F2[getUserById]
            ADMIN_F3[updateUser]
            ADMIN_F4[deleteUser]
            ADMIN_F5[setUserRole]
            ADMIN_F6[getUserAnalytics]
        end

        subgraph "userCollectionController.js"
            COLL_F1[getUserCollections]
            COLL_F2[assignCollection]
            COLL_F3[trackCollectionAccess]
            COLL_F4[manageTimeFrames]
            COLL_F5[getAccessHistory]
            COLL_F6[updateProgress]
        end
    end

    UC_F1 --> AUTH_F1
    UC_F2 --> AUTH_F2
    UC_F3 --> AUTH_F3
    UC_F4 --> PROF_F1
    UC_F5 --> PROF_F2
    UC_F6 --> ADMIN_F1
    UC_F7 --> ADMIN_F4
    UC_F8 --> COLL_F1
    UC_F9 --> COLL_F2
    UC_F10 --> COLL_F3
    UC_F11 --> PROF_F3
    UC_F12 --> AUTH_F5
    UC_F13 --> PROF_F5
    UC_F14 --> COLL_F4
    UC_F15 --> COLL_F5

    classDef original fill:#ff6b6b,stroke:#d63031,stroke-width:2px,color:#fff
    classDef auth fill:#4caf50,stroke:#388e3c,stroke-width:2px,color:#fff
    classDef profile fill:#2196f3,stroke:#1976d2,stroke-width:2px,color:#fff
    classDef admin fill:#ff9800,stroke:#f57c00,stroke-width:2px,color:#fff
    classDef collection fill:#9c27b0,stroke:#7b1fa2,stroke-width:2px,color:#fff

    class UC_F1,UC_F2,UC_F3,UC_F4,UC_F5,UC_F6,UC_F7,UC_F8,UC_F9,UC_F10,UC_F11,UC_F12,UC_F13,UC_F14,UC_F15 original
    class AUTH_F1,AUTH_F2,AUTH_F3,AUTH_F4,AUTH_F5 auth
    class PROF_F1,PROF_F2,PROF_F3,PROF_F4,PROF_F5 profile
    class ADMIN_F1,ADMIN_F2,ADMIN_F3,ADMIN_F4,ADMIN_F5,ADMIN_F6 admin
    class COLL_F1,COLL_F2,COLL_F3,COLL_F4,COLL_F5,COLL_F6 collection
```

## NEW ROUTE STRUCTURE

```mermaid
graph TB
    subgraph "CURRENT ROUTES (Confusing)"
        CR1[/api/users/auth - POST]
        CR2[/api/users/register - POST]
        CR3[/api/users/profile - GET, PUT]
        CR4[/api/users - GET (admin)]
        CR5[/api/users/:id - GET, PUT, DELETE]
        CR6[/api/users/collections - GET]
        CR7[/api/users/assign-collection - POST]
        CR8[/api/users/upload-image - POST]
    end

    subgraph "PROPOSED ROUTES (Clear & Organized)"
        subgraph "Authentication Routes"
            NR1[/api/auth/login - POST]
            NR2[/api/auth/register - POST]
            NR3[/api/auth/logout - POST]
            NR4[/api/auth/refresh - POST]
            NR5[/api/auth/forgot-password - POST]
        end

        subgraph "Profile Routes"
            NR6[/api/profile - GET, PUT]
            NR7[/api/profile/image - POST]
            NR8[/api/profile/delete - DELETE]
            NR9[/api/profile/verify-email - POST]
        end

        subgraph "Admin User Routes"
            NR10[/api/admin/users - GET, POST]
            NR11[/api/admin/users/:id - GET, PUT, DELETE]
            NR12[/api/admin/users/:id/role - PUT]
            NR13[/api/admin/users/analytics - GET]
        end

        subgraph "User Collection Routes"
            NR14[/api/user/collections - GET]
            NR15[/api/user/collections/assign - POST]
            NR16[/api/user/collections/:id/access - POST]
            NR17[/api/user/collections/history - GET]
            NR18[/api/user/time-frames - GET, POST]
        end
    end

    classDef current fill:#ff6b6b,stroke:#d63031,stroke-width:2px,color:#fff
    classDef auth fill:#4caf50,stroke:#388e3c,stroke-width:2px,color:#fff
    classDef profile fill:#2196f3,stroke:#1976d2,stroke-width:2px,color:#fff
    classDef admin fill:#ff9800,stroke:#f57c00,stroke-width:2px,color:#fff
    classDef collection fill:#9c27b0,stroke:#7b1fa2,stroke-width:2px,color:#fff

    class CR1,CR2,CR3,CR4,CR5,CR6,CR7,CR8 current
    class NR1,NR2,NR3,NR4,NR5 auth
    class NR6,NR7,NR8,NR9 profile
    class NR10,NR11,NR12,NR13 admin
    class NR14,NR15,NR16,NR17,NR18 collection
```

## BENEFITS AFTER REFACTORING

```mermaid
graph TB
    subgraph "BEFORE REFACTORING"
        B1[Single 1,898-line file]
        B2[Hard to navigate]
        B3[Merge conflicts]
        B4[Poor testability]
        B5[Mixed responsibilities]
        B6[Difficult debugging]
    end

    subgraph "AFTER REFACTORING"
        A1[4 focused controllers<br/>200-600 lines each]
        A2[Easy navigation]
        A3[Parallel development]
        A4[High testability]
        A5[Clear responsibilities]
        A6[Easy debugging]
    end

    subgraph "QUANTIFIED IMPROVEMENTS"
        I1[File Size: 70% reduction]
        I2[Development Speed: 40% faster]
        I3[Bug Detection: 60% easier]
        I4[Code Reviews: 50% faster]
        I5[New Feature Development: 45% faster]
        I6[Testing Coverage: 80%+ achievable]
    end

    B1 --> A1
    B2 --> A2
    B3 --> A3
    B4 --> A4
    B5 --> A5
    B6 --> A6

    A1 --> I1
    A2 --> I2
    A4 --> I3
    A3 --> I4
    A5 --> I5
    A4 --> I6

    classDef before fill:#ff6b6b,stroke:#d63031,stroke-width:2px,color:#fff
    classDef after fill:#00b894,stroke:#00a085,stroke-width:2px,color:#fff
    classDef improvement fill:#6c5ce7,stroke:#5f3dc4,stroke-width:2px,color:#fff

    class B1,B2,B3,B4,B5,B6 before
    class A1,A2,A3,A4,A5,A6 after
    class I1,I2,I3,I4,I5,I6 improvement
```

This refactoring diagram provides a clear roadmap for breaking down oversized controllers into manageable, focused components that follow the Single Responsibility Principle. 