# USER JOURNEY DIAGRAMS

## OVERVIEW
This document maps complete user journeys through the GrindX system, showing all touchpoints, API calls, and data flows from registration to advanced usage.

## NEW USER ONBOARDING JOURNEY

```mermaid
journey
    title New User Complete Onboarding Journey
    section Registration
      Visit landing page: 3: User
      Fill registration form: 4: User
      Submit registration: 5: User, Frontend
      Validate email format: 3: Frontend
      Check email availability: 2: Backend
      Hash password: 1: Backend
      Save user to database: 1: Backend
      Generate JWT token: 2: Backend
      Send welcome email: 3: Backend
    section Initial Setup
      Redirect to dashboard: 5: User, Frontend
      Show onboarding tour: 4: User, Frontend
      Request WhatsApp number: 3: User, Frontend
      Verify WhatsApp: 2: User, Backend
      Upload profile picture: 4: User, Frontend, Cloudinary
      Set initial preferences: 3: User, Frontend, Backend
    section First Collection Access
      Browse available collections: 5: User, Frontend
      Select collection: 4: User
      Check access permissions: 2: Backend
      Request access via one-time code: 3: User, Frontend
      Admin generates code: 2: Admin, Backend
      Receive WhatsApp notification: 4: User, WhatsApp
      Enter access code: 5: User, Frontend
      Verify code: 2: Backend
      Grant collection access: 3: Backend
      Update user permissions: 1: Backend
    section First Workout
      Access granted collection: 5: User, Frontend
      View workout content: 5: User, Frontend
      Start workout tracking: 4: User, Frontend
      Log workout progress: 3: User, Frontend, Backend
      Complete workout: 5: User
      Save workout data: 2: Backend
      Update user statistics: 1: Backend
      Show achievement: 4: User, Frontend
```

## ADMIN COLLECTION MANAGEMENT JOURNEY

```mermaid
journey
    title Admin Collection Management Workflow
    section Content Planning
      Analyze user requests: 4: Admin
      Plan new collection: 5: Admin
      Prepare workout content: 4: Admin
      Create product specifications: 3: Admin
    section Collection Creation
      Login to admin dashboard: 5: Admin, Frontend
      Navigate to collections: 4: Admin, Frontend
      Click create new collection: 5: Admin, Frontend
      Fill collection details: 4: Admin, Frontend
      Upload collection image: 3: Admin, Frontend, Cloudinary
      Add workout videos: 4: Admin, Frontend, Cloudinary
      Set collection pricing: 3: Admin, Frontend
      Configure access rules: 2: Admin, Frontend, Backend
    section Product Management
      Add products to collection: 4: Admin, Frontend
      Set product categories: 3: Admin, Frontend
      Upload product images: 3: Admin, Frontend, Cloudinary
      Configure product pricing: 3: Admin, Frontend
      Set inventory levels: 2: Admin, Frontend, Backend
    section Access Control
      Create user groups: 3: Admin, Frontend, Backend
      Generate one-time codes: 4: Admin, Frontend, Backend
      Set code expiration: 3: Admin, Frontend
      Configure WhatsApp templates: 2: Admin, Frontend, Backend
      Send codes to users: 3: Admin, Backend, WhatsApp
    section Analytics & Monitoring
      View collection analytics: 5: Admin, Frontend
      Monitor user engagement: 4: Admin, Frontend, Backend
      Track revenue metrics: 4: Admin, Frontend, Backend
      Generate usage reports: 3: Admin, Frontend, Backend
      Optimize based on data: 5: Admin
```

## USER WORKOUT PROGRESSION JOURNEY

```mermaid
journey
    title User Workout Progression Over Time
    section Week 1 - Beginner
      Access beginner collection: 5: User, Frontend
      Complete first workout: 4: User, Frontend
      Log basic metrics: 3: User, Frontend, Backend
      Struggle with form: 2: User
      Watch instructional videos: 4: User, Frontend
      Complete week 1: 3: User
    section Week 4 - Progress
      Notice improvements: 5: User
      Access intermediate collection: 4: User, Frontend
      Request trainer consultation: 3: User, Frontend, Backend
      Receive personalized advice: 4: User, WhatsApp
      Track advanced metrics: 4: User, Frontend, Backend
      Share progress with friends: 5: User, Frontend
    section Month 3 - Advanced
      Master intermediate routines: 5: User
      Request advanced collection: 4: User, Frontend
      Admin reviews progress: 3: Admin, Backend
      Granted advanced access: 4: User, Backend
      Customize workout plans: 5: User, Frontend, Backend
      Mentor new users: 5: User, Frontend
    section Month 6 - Expert
      Complete transformation: 5: User
      Become community leader: 5: User, Frontend
      Create custom workouts: 4: User, Frontend, Backend
      Share success story: 5: User, Frontend
      Inspire others: 5: User, Community
```

## ONE-TIME CODE USAGE JOURNEY

```mermaid
sequenceDiagram
    participant User
    participant WhatsApp
    participant Frontend
    participant Backend
    participant Admin
    participant Database

    Note over User,Database: Complete One-Time Code Workflow

    Admin->>Frontend: Create bulk access codes
    Frontend->>Backend: POST /api/one-time-codes/bulk
    Backend->>Database: Save codes with expiration
    Backend->>Backend: Generate WhatsApp messages
    Backend->>WhatsApp: Send codes to user list
    WhatsApp-->>User: Receive access code message

    Note over User: User Journey Begins

    User->>User: Reads WhatsApp message
    User->>Frontend: Opens app/website
    User->>Frontend: Navigates to "Enter Code" page
    User->>Frontend: Types 6-digit code
    Frontend->>Frontend: Validates format locally
    Frontend->>Backend: POST /api/one-time-codes/verify

    Backend->>Database: Query code validity
    alt Code Valid & Not Expired
        Database-->>Backend: Valid code found
        Backend->>Database: Mark code as used
        Backend->>Database: Get allowed collections
        Backend->>Database: Update user permissions
        Backend-->>Frontend: Success + collection list
        Frontend-->>User: "Access Granted" + redirect
        User->>Frontend: Browse new collections
        Frontend->>Backend: GET /api/user/collections
        Backend->>Database: Get user's collections
        Database-->>Backend: Collection list
        Backend-->>Frontend: Collections with access
        Frontend-->>User: Display available workouts
    else Code Invalid/Expired
        Database-->>Backend: Code not found/expired
        Backend-->>Frontend: Error message
        Frontend-->>User: "Invalid or expired code"
        User->>Frontend: Request new code
        Frontend->>Backend: POST /api/support/request-code
        Backend->>Admin: Notification of code request
        Admin->>Backend: Generate new code
        Backend->>WhatsApp: Send new code
        WhatsApp-->>User: New code received
    end
```

## E-COMMERCE PURCHASE JOURNEY

```mermaid
journey
    title Complete Purchase Journey
    section Product Discovery
      Browse product catalog: 5: User, Frontend
      Filter by category: 4: User, Frontend
      Read product reviews: 4: User, Frontend, Backend
      Compare similar products: 3: User, Frontend
      View product details: 5: User, Frontend
      Watch demo videos: 4: User, Frontend
    section Purchase Decision
      Add product to cart: 5: User, Frontend
      Review cart contents: 4: User, Frontend
      Apply discount codes: 3: User, Frontend, Backend
      Calculate total with tax: 2: Frontend, Backend
      Proceed to checkout: 5: User, Frontend
    section Payment Process
      Enter shipping details: 3: User, Frontend
      Select payment method: 4: User, Frontend
      Redirect to PayPal: 3: User, PayPal
      Complete PayPal payment: 4: User, PayPal
      Return to confirmation: 5: User, Frontend, Backend
      Receive order confirmation: 4: User, Frontend, Backend
      Get email receipt: 3: User, Email
    section Order Fulfillment
      Admin processes order: 3: Admin, Backend
      Inventory updated: 2: Backend, Database
      Shipping notification sent: 3: User, Email, WhatsApp
      Track shipment: 4: User, Frontend
      Receive product: 5: User
      Leave product review: 4: User, Frontend, Backend
    section Post-Purchase
      Access related workouts: 5: User, Frontend
      Join product community: 4: User, Frontend
      Share purchase success: 4: User, Social
      Recommend to friends: 5: User, Social
      Become repeat customer: 5: User
```

## ADMIN ANALYTICS & MANAGEMENT JOURNEY

```mermaid
journey
    title Daily Admin Management Workflow
    section Morning Review
      Login to admin dashboard: 5: Admin, Frontend
      Check overnight registrations: 4: Admin, Frontend, Backend
      Review pending orders: 4: Admin, Frontend, Backend
      Monitor system health: 3: Admin, Frontend, Backend
      Check WhatsApp integration: 3: Admin, Backend, WhatsApp
    section User Management
      Review user access requests: 4: Admin, Frontend, Backend
      Generate one-time codes: 3: Admin, Frontend, Backend
      Process user support tickets: 3: Admin, Frontend, Backend
      Update user permissions: 2: Admin, Backend, Database
      Send bulk communications: 3: Admin, Backend, WhatsApp
    section Content Management
      Upload new workout videos: 4: Admin, Frontend, Cloudinary
      Create new collections: 4: Admin, Frontend, Backend
      Update product catalog: 3: Admin, Frontend, Backend
      Manage pricing strategies: 3: Admin, Frontend, Backend
      Schedule content releases: 2: Admin, Backend, Database
    section Analytics Review
      Check user engagement: 5: Admin, Frontend, Backend
      Analyze revenue trends: 4: Admin, Frontend, Backend
      Monitor collection popularity: 4: Admin, Frontend, Backend
      Review conversion rates: 3: Admin, Frontend, Backend
      Plan improvements: 5: Admin
    section Evening Wrap-up
      Process day's orders: 3: Admin, Frontend, Backend
      Update shipping status: 2: Admin, Backend, Database
      Send delivery notifications: 3: Admin, Backend, WhatsApp
      Backup critical data: 1: Admin, Backend, Database
      Plan next day priorities: 5: Admin
```

## USER RETENTION & ENGAGEMENT JOURNEY

```mermaid
journey
    title Long-term User Engagement Journey
    section Month 1 - Honeymoon
      High initial enthusiasm: 5: User
      Daily app usage: 5: User, Frontend
      Complete beginner workouts: 4: User, Frontend, Backend
      Share initial progress: 4: User, Social
      Engage with community: 3: User, Frontend
    section Month 2-3 - Reality Check
      Motivation decreases: 2: User
      Skip some workouts: 2: User
      Receive motivational messages: 4: System, WhatsApp
      Get encouragement from community: 4: Community, Frontend
      Admin sends personalized tips: 3: Admin, WhatsApp
    section Month 4-6 - Habit Formation
      Establish routine: 4: User
      See physical improvements: 5: User
      Unlock intermediate content: 4: User, Backend
      Become community helper: 4: User, Frontend
      Share success milestones: 5: User, Social
    section Month 7-12 - Mastery
      Achieve fitness goals: 5: User
      Mentor new users: 5: User, Frontend
      Request advanced content: 4: User, Frontend, Backend
      Provide feedback to admin: 4: User, Admin
      Become brand ambassador: 5: User
    section Year 2+ - Loyalty
      Consistent long-term usage: 5: User, Frontend
      Purchase premium products: 4: User, Frontend, Backend
      Refer friends and family: 5: User, Social
      Provide content suggestions: 4: User, Admin
      Lifetime customer value: 5: Business
```

## SYSTEM PAIN POINTS IN USER JOURNEYS

```mermaid
graph TB
    subgraph "Registration Issues"
        R1[Slow email validation: 3-5 seconds]
        R2[Database timeout on peak hours]
        R3[WhatsApp verification delays]
    end

    subgraph "Collection Access Issues"
        C1[Embedded array scanning: 200-300ms]
        C2[N+1 queries for products]
        C3[Manual code generation process]
    end

    subgraph "Performance Issues"
        P1[Large file downloads: 1,898 lines]
        P2[Unoptimized database queries]
        P3[No caching for frequently accessed data]
    end

    subgraph "User Experience Impact"
        U1[Frustration with slow loading]
        U2[Abandonment during registration]
        U3[Confusion with access codes]
        U4[Poor mobile experience]
    end

    R1 --> U2
    R2 --> U1
    C1 --> U1
    C2 --> U1
    P1 --> U4
    P2 --> U1
    C3 --> U3

    classDef issue fill:#ff6b6b,stroke:#d63031,stroke-width:2px,color:#fff
    classDef impact fill:#fd79a8,stroke:#e84393,stroke-width:2px,color:#fff

    class R1,R2,R3,C1,C2,C3,P1,P2,P3 issue
    class U1,U2,U3,U4 impact
```

## OPTIMIZED USER JOURNEY (POST-REFACTORING)

```mermaid
journey
    title Optimized User Experience Journey
    section Fast Registration
      Visit landing page: 5: User
      Quick form validation: 5: Frontend
      Instant email check: 5: Backend, Cache
      Fast user creation: 5: Backend, Database
      Immediate WhatsApp verification: 5: Backend, WhatsApp
      Welcome dashboard: 5: User, Frontend
    section Smooth Collection Access
      Browse collections (cached): 5: User, Frontend, Cache
      Instant access check: 5: Backend, Optimized DB
      Quick code verification: 5: Backend
      Immediate access grant: 5: Backend
      Fast content loading: 5: Frontend, CDN
    section Excellent Performance
      Sub-second page loads: 5: User, Frontend
      Real-time updates: 5: User, WebSocket
      Offline capability: 4: User, PWA
      Smooth animations: 5: User, Frontend
      Excellent mobile experience: 5: User, Mobile
```

These user journey diagrams highlight the complete user experience and identify critical points where system performance and architecture improvements will have the most impact on user satisfaction. 