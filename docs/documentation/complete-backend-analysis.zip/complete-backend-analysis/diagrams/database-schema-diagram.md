# DATABASE SCHEMA DIAGRAM

## OVERVIEW
This diagram shows the complete database schema, relationships between models, and identifies areas needing optimization.

## CURRENT DATABASE SCHEMA

```mermaid
erDiagram
    User ||--o{ Order : "places"
    User ||--o{ WorkoutEntry : "creates"
    User ||--o{ OneTimeCode : "generates"
    User }o--o{ Collection : "accesses"
    Collection ||--o{ Product : "contains"
    Product ||--o{ OrderItem : "ordered_as"
    Order ||--o{ OrderItem : "contains"
    MessageTemplate ||--o{ OneTimeCode : "uses"

    User {
        ObjectId _id PK
        String name "Required"
        String email "Required, Unique"
        String password "Required, Hashed"
        Boolean isAdmin "Default: false"
        String whatsAppPhoneNumber "Optional"
        String profileImageUrl "Optional"
        Date createdAt "Auto"
        Date updatedAt "Auto"
        
        EmbeddedArray assignedCollections "⚠️ UNBOUNDED"
        EmbeddedArray accessedCollections "⚠️ UNBOUNDED"
        EmbeddedArray lockedCollections "⚠️ UNBOUNDED"
        EmbeddedArray timeFrameHistory "⚠️ UNBOUNDED"
        EmbeddedArray contactTracking "⚠️ UNBOUNDED"
        EmbeddedArray devices "⚠️ UNBOUNDED"
        
        String currentTimeFrame "Optional"
        Date timeFrameStartDate "Optional"
        Date timeFrameEndDate "Optional"
        Boolean timeFrameActive "Default: false"
    }

    Collection {
        ObjectId _id PK
        String name "Required"
        String description "Optional"
        String imageUrl "Optional"
        String videoUrl "Optional"
        Boolean isActive "Default: true"
        ObjectId parentId "Optional, Self-ref"
        Number order "Default: 0"
        Date createdAt "Auto"
        Date updatedAt "Auto"
        
        EmbeddedArray products "References to Product"
        EmbeddedArray subCollections "Child collections"
        
        String collectionType "Enum: workout, nutrition, etc"
        Object metadata "Flexible schema"
    }

    Product {
        ObjectId _id PK
        String name "Required"
        String description "Required"
        String imageUrl "Required"
        String videoUrl "Optional"
        Number price "Default: 0"
        String category "Required"
        Boolean isActive "Default: true"
        Date createdAt "Auto"
        Date updatedAt "Auto"
        
        Number rating "Default: 0"
        Number numReviews "Default: 0"
        EmbeddedArray reviews "Review subdocs"
        
        Object specifications "Flexible schema"
        Array tags "String array"
    }

    Order {
        ObjectId _id PK
        ObjectId user FK
        Array orderItems "OrderItem subdocs"
        Object shippingAddress "Address object"
        String paymentMethod "Required"
        Object paymentResult "PayPal response"
        Number itemsPrice "Calculated"
        Number taxPrice "Calculated" 
        Number shippingPrice "Calculated"
        Number totalPrice "Calculated"
        Boolean isPaid "Default: false"
        Date paidAt "Optional"
        Boolean isDelivered "Default: false"
        Date deliveredAt "Optional"
        Date createdAt "Auto"
        Date updatedAt "Auto"
    }

    OrderItem {
        String name "Product name"
        Number qty "Quantity"
        String image "Product image"
        Number price "Product price"
        ObjectId product "Product reference"
    }

    OneTimeCode {
        ObjectId _id PK
        String code "Required, Unique, 6-digits"
        ObjectId userId "Optional"
        String email "Optional"
        String whatsAppNumber "Optional"
        Date expiresAt "Required"
        Boolean isUsed "Default: false"
        Date usedAt "Optional"
        Number maxUses "Default: 1"
        Number currentUses "Default: 0"
        String purpose "Enum: verification, access, etc"
        ObjectId messageTemplateId "Optional"
        Date createdAt "Auto"
        Date updatedAt "Auto"
        
        Array allowedCollections "Collection IDs"
        Object metadata "Flexible data"
    }

    MessageTemplate {
        ObjectId _id PK
        String name "Required"
        String subject "Email subject"
        String message "Required"
        String type "Enum: email, sms, whatsapp"
        Boolean isActive "Default: true"
        Object variables "Template variables"
        Date createdAt "Auto"
        Date updatedAt "Auto"
    }

    WorkoutEntry {
        ObjectId _id PK
        ObjectId user FK
        ObjectId collectionId "Optional"
        String workoutType "Required"
        Number duration "Minutes"
        Number caloriesBurned "Optional"
        String notes "Optional"
        Date workoutDate "Required"
        Date createdAt "Auto"
        Date updatedAt "Auto"
        
        Array exercises "Exercise details"
        Object metrics "Performance data"
    }

    SystemSettings {
        ObjectId _id PK
        String key "Required, Unique"
        Mixed value "Any type"
        String description "Optional"
        String category "Optional"
        Boolean isActive "Default: true"
        Date createdAt "Auto"
        Date updatedAt "Auto"
    }
```

## CRITICAL DATABASE ISSUES

### 🔴 PERFORMANCE PROBLEMS

```mermaid
graph TB
    subgraph "User Model Issues (857 lines)"
        U1[Embedded Arrays Growing Unbounded]
        U2[assignedCollections Array]
        U3[accessedCollections Array]
        U4[lockedCollections Array]
        U5[timeFrameHistory Array]
        U6[contactTracking Array]
        U7[devices Array]
    end

    subgraph "Missing Indexes"
        I1[No email index on users]
        I2[No isAdmin index]
        I3[No collection parentId index]
        I4[No oneTimeCode.code index]
        I5[No product.category index]
        I6[No order.user index]
    end

    subgraph "Query Problems"
        Q1[N+1 Queries in Collection Fetching]
        Q2[No Aggregation Pipelines]
        Q3[Full Document Retrieval]
        Q4[No Field Projection]
    end

    U1 --> SLOW[Slow Queries<br/>200-300ms]
    I1 --> SLOW
    I2 --> SLOW
    Q1 --> SLOW

    U2 --> MEMORY[High Memory Usage]
    U3 --> MEMORY
    U4 --> MEMORY

    Q3 --> BANDWIDTH[High Network Usage]
    Q4 --> BANDWIDTH

    classDef critical fill:#ff6b6b,stroke:#d63031,stroke-width:3px,color:#fff
    classDef warning fill:#fdcb6e,stroke:#e17055,stroke-width:2px
    classDef impact fill:#fd79a8,stroke:#e84393,stroke-width:2px,color:#fff

    class U1,U2,U3,U4,U5,U6,U7,I1,I2,I3,I4,I5,I6,Q1,Q2,Q3,Q4 critical
    class SLOW,MEMORY,BANDWIDTH impact
```

## PROPOSED OPTIMIZED SCHEMA

```mermaid
erDiagram
    UserCore ||--o{ UserCollectionAccess : "has"
    UserCore ||--o{ UserTimeFrame : "has"
    UserCore ||--o{ UserContactTracker : "has"
    UserCore ||--o{ UserDevice : "has"
    UserCore ||--o{ Order : "places"
    UserCore ||--o{ WorkoutEntry : "creates"
    
    Collection ||--o{ UserCollectionAccess : "accessed_by"
    Collection ||--o{ Product : "contains"
    Collection ||--o{ Collection : "parent_of"
    
    Product ||--o{ OrderItem : "ordered_as"
    Product ||--o{ ProductReview : "has"
    Order ||--o{ OrderItem : "contains"
    
    OneTimeCode }o--|| MessageTemplate : "uses"

    UserCore {
        ObjectId _id PK "🔑 PRIMARY KEY"
        String name "Required"
        String email "Required 📧 UNIQUE INDEX"
        String password "Required, Hashed"
        Boolean isAdmin "Default: false 👑 INDEX"
        String whatsAppPhoneNumber "🔍 INDEX"
        String profileImageUrl "Optional"
        String currentTimeFrame "Optional"
        Date timeFrameStartDate "Optional"
        Date timeFrameEndDate "Optional"
        Boolean timeFrameActive "Default: false"
        Date createdAt "Auto 📅 INDEX"
        Date updatedAt "Auto"
    }

    UserCollectionAccess {
        ObjectId _id PK
        ObjectId userId FK "🔍 INDEX"
        ObjectId collectionId FK "🔍 INDEX"
        String accessType "assigned|accessed|locked"
        Date firstAccessedAt "Optional"
        Date lastAccessedAt "🔍 INDEX"
        Number accessCount "Default: 0"
        Number progressPercentage "Default: 0"
        Boolean isActive "Default: true"
        Date createdAt "Auto"
        Date updatedAt "Auto"
    }

    UserTimeFrame {
        ObjectId _id PK
        ObjectId userId FK "🔍 INDEX"
        String timeFrameType "weekly|monthly|custom"
        Date startDate "Required 📅 INDEX"
        Date endDate "Required 📅 INDEX"
        Boolean isActive "Default: false"
        Object metadata "Flexible data"
        Date createdAt "Auto"
        Date updatedAt "Auto"
    }

    UserContactTracker {
        ObjectId _id PK
        ObjectId userId FK "🔍 INDEX"
        String contactMethod "email|whatsapp|sms"
        String contactValue "Contact info"
        String verificationStatus "pending|verified|failed"
        Date lastContactAt "🔍 INDEX"
        Number contactCount "Default: 0"
        Date createdAt "Auto"
        Date updatedAt "Auto"
    }

    UserDevice {
        ObjectId _id PK
        ObjectId userId FK "🔍 INDEX"
        String deviceId "Unique device identifier"
        String deviceType "mobile|desktop|tablet"
        String userAgent "Browser/app info"
        String ipAddress "Last known IP"
        Date lastActiveAt "🔍 INDEX"
        Boolean isActive "Default: true"
        Date createdAt "Auto"
        Date updatedAt "Auto"
    }

    Collection {
        ObjectId _id PK
        String name "Required"
        String description "Optional"
        String imageUrl "Optional"
        String videoUrl "Optional"
        Boolean isActive "Default: true 🔍 INDEX"
        ObjectId parentId "Optional 🔍 INDEX"
        Number order "Default: 0"
        String collectionType "🔍 INDEX"
        Object metadata "Flexible schema"
        Date createdAt "Auto 📅 INDEX"
        Date updatedAt "Auto"
    }

    Product {
        ObjectId _id PK
        String name "Required 🔍 TEXT INDEX"
        String description "Required"
        String imageUrl "Required"
        String videoUrl "Optional"
        Number price "Default: 0 💰 INDEX"
        String category "Required 🔍 INDEX"
        Boolean isActive "Default: true 🔍 INDEX"
        Number rating "Default: 0"
        Number numReviews "Default: 0"
        Object specifications "Flexible schema"
        Array tags "String array 🔍 INDEX"
        Date createdAt "Auto 📅 INDEX"
        Date updatedAt "Auto"
    }

    ProductReview {
        ObjectId _id PK
        ObjectId productId FK "🔍 INDEX"
        ObjectId userId FK "🔍 INDEX"
        String name "Reviewer name"
        Number rating "1-5 required"
        String comment "Required"
        Boolean isVerified "Default: false"
        Date createdAt "Auto 📅 INDEX"
        Date updatedAt "Auto"
    }

    Order {
        ObjectId _id PK
        ObjectId user FK "🔍 INDEX"
        Array orderItems "OrderItem subdocs"
        Object shippingAddress "Address object"
        String paymentMethod "Required"
        Object paymentResult "PayPal response"
        Number itemsPrice "Calculated"
        Number taxPrice "Calculated"
        Number shippingPrice "Calculated" 
        Number totalPrice "Calculated 💰 INDEX"
        Boolean isPaid "Default: false 🔍 INDEX"
        Date paidAt "Optional"
        Boolean isDelivered "Default: false 🔍 INDEX"
        Date deliveredAt "Optional"
        Date createdAt "Auto 📅 INDEX"
        Date updatedAt "Auto"
    }

    OneTimeCode {
        ObjectId _id PK
        String code "Required 🔑 UNIQUE INDEX"
        ObjectId userId "Optional 🔍 INDEX"
        String email "Optional"
        String whatsAppNumber "Optional"
        Date expiresAt "Required 📅 INDEX"
        Boolean isUsed "Default: false 🔍 INDEX"
        Date usedAt "Optional"
        Number maxUses "Default: 1"
        Number currentUses "Default: 0"
        String purpose "🔍 INDEX"
        ObjectId messageTemplateId "Optional"
        Array allowedCollections "Collection IDs"
        Object metadata "Flexible data"
        Date createdAt "Auto 📅 INDEX"
        Date updatedAt "Auto"
    }

    MessageTemplate {
        ObjectId _id PK
        String name "Required 🔍 INDEX"
        String subject "Email subject"
        String message "Required"
        String type "🔍 INDEX email|sms|whatsapp"
        Boolean isActive "Default: true 🔍 INDEX"
        Object variables "Template variables"
        Date createdAt "Auto"
        Date updatedAt "Auto"
    }

    WorkoutEntry {
        ObjectId _id PK
        ObjectId user FK "🔍 INDEX"
        ObjectId collectionId "Optional 🔍 INDEX"
        String workoutType "Required 🔍 INDEX"
        Number duration "Minutes"
        Number caloriesBurned "Optional"
        String notes "Optional"
        Date workoutDate "Required 📅 INDEX"
        Array exercises "Exercise details"
        Object metrics "Performance data"
        Date createdAt "Auto"
        Date updatedAt "Auto"
    }

    SystemSettings {
        ObjectId _id PK
        String key "Required 🔑 UNIQUE INDEX"
        Mixed value "Any type"
        String description "Optional"
        String category "🔍 INDEX"
        Boolean isActive "Default: true 🔍 INDEX"
        Date createdAt "Auto"
        Date updatedAt "Auto"
    }
```

## MIGRATION STRATEGY

```mermaid
graph TD
    subgraph "Phase 1: Index Creation"
        A1[Add Critical Indexes]
        A2[User.email unique index]
        A3[User.isAdmin index]
        A4[Collection.parentId index]
        A5[OneTimeCode.code unique index]
    end

    subgraph "Phase 2: Model Decomposition"
        B1[Extract UserCollectionAccess]
        B2[Extract UserTimeFrame]
        B3[Extract UserContactTracker]
        B4[Extract UserDevice]
        B5[Extract ProductReview]
    end

    subgraph "Phase 3: Data Migration"
        C1[Migrate Embedded Arrays]
        C2[Update Application Code]
        C3[Remove Old Fields]
        C4[Verify Data Integrity]
    end

    A1 --> A2
    A2 --> A3
    A3 --> A4
    A4 --> A5
    A5 --> B1
    B1 --> B2
    B2 --> B3
    B3 --> B4
    B4 --> B5
    B5 --> C1
    C1 --> C2
    C2 --> C3
    C3 --> C4

    classDef phase1 fill:#e8f5e8,stroke:#4caf50,stroke-width:2px
    classDef phase2 fill:#e3f2fd,stroke:#2196f3,stroke-width:2px
    classDef phase3 fill:#fff3e0,stroke:#ff9800,stroke-width:2px

    class A1,A2,A3,A4,A5 phase1
    class B1,B2,B3,B4,B5 phase2
    class C1,C2,C3,C4 phase3
```

## EXPECTED PERFORMANCE IMPROVEMENTS

```mermaid
graph LR
    subgraph "Before Optimization"
        B1[User Query: 300ms]
        B2[Collection Query: 250ms]
        B3[N+1 Queries: 500ms+]
        B4[Full Document: 2MB]
    end

    subgraph "After Optimization"
        A1[User Query: 50ms ⚡]
        A2[Collection Query: 80ms ⚡]
        A3[Aggregated Query: 100ms ⚡]
        A4[Projected Fields: 200KB ⚡]
    end

    B1 --> A1
    B2 --> A2
    B3 --> A3
    B4 --> A4

    classDef before fill:#ff6b6b,stroke:#d63031,stroke-width:2px,color:#fff
    classDef after fill:#00b894,stroke:#00a085,stroke-width:2px,color:#fff

    class B1,B2,B3,B4 before
    class A1,A2,A3,A4 after
```

This database schema diagram shows the current complex structure and the proposed optimized schema with proper indexing and normalized relationships. 