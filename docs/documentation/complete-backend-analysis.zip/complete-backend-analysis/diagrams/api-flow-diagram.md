# API FLOW DIAGRAMS

## OVERVIEW
This document provides detailed flow diagrams for all major API operations, showing request/response cycles, authentication flows, and data processing.

## AUTHENTICATION FLOW

```mermaid
sequenceDiagram
    participant Client
    participant Frontend
    participant AuthMiddleware
    participant UserController
    participant UserModel
    participant Database
    participant JWTUtils

    Note over Client,JWTUtils: User Registration Flow

    Client->>Frontend: Fill registration form
    Frontend->>UserController: POST /api/users/register
    UserController->>UserModel: Check if user exists
    UserModel->>Database: findOne({ email })
    
    alt User exists
        Database-->>UserModel: User found
        UserModel-->>UserController: User exists error
        UserController-->>Frontend: 400 - User already exists
        Frontend-->>Client: Show error message
    else New user
        Database-->>UserModel: No user found
        UserModel->>Database: create({ name, email, password })
        Database-->>UserModel: New user created
        UserModel-->>UserController: User object
        UserController->>JWTUtils: generateToken(userId)
        JWTUtils-->>UserController: JWT token
        UserController-->>Frontend: 201 - User created + Set cookie
        Frontend-->>Client: Redirect to dashboard
    end

    Note over Client,JWTUtils: User Login Flow

    Client->>Frontend: Enter credentials
    Frontend->>UserController: POST /api/users/auth
    UserController->>UserModel: findOne({ email })
    UserModel->>Database: Query user by email
    Database-->>UserModel: User data
    UserModel->>UserModel: matchPassword(enteredPassword)
    
    alt Valid credentials
        UserModel-->>UserController: Password match
        UserController->>JWTUtils: generateToken(userId)
        JWTUtils-->>UserController: JWT token
        UserController-->>Frontend: 200 - User data + Set cookie
        Frontend-->>Client: Redirect to dashboard
    else Invalid credentials
        UserModel-->>UserController: Password mismatch
        UserController-->>Frontend: 401 - Invalid credentials
        Frontend-->>Client: Show error message
    end

    Note over Client,JWTUtils: Protected Route Access

    Client->>Frontend: Access protected page
    Frontend->>AuthMiddleware: Request with JWT cookie
    AuthMiddleware->>JWTUtils: Verify token
    
    alt Valid token
        JWTUtils-->>AuthMiddleware: Token valid
        AuthMiddleware->>UserModel: findById(userId)
        UserModel->>Database: Get user by ID
        Database-->>UserModel: User data
        UserModel-->>AuthMiddleware: User object
        AuthMiddleware->>UserController: Continue with user in req.user
        UserController-->>Frontend: Protected data
        Frontend-->>Client: Show protected content
    else Invalid token
        JWTUtils-->>AuthMiddleware: Token invalid
        AuthMiddleware-->>Frontend: 401 - Not authorized
        Frontend-->>Client: Redirect to login
    end
```

## USER COLLECTION ACCESS FLOW

```mermaid
sequenceDiagram
    participant User
    participant Frontend
    participant Auth
    participant UserController
    participant CollectionController
    participant UserModel
    participant CollectionModel
    participant Database

    Note over User,Database: Collection Assignment & Access Flow

    User->>Frontend: Browse collections
    Frontend->>Auth: Verify user token
    Auth->>CollectionController: GET /api/collections
    CollectionController->>CollectionModel: find({ isActive: true })
    CollectionModel->>Database: Query active collections
    
    rect rgb(255, 107, 107)
        Note over Database: ⚠️ PERFORMANCE ISSUE
        Database-->>CollectionModel: All collections (Full documents)
        CollectionModel->>CollectionModel: Populate products (N+1 queries)
        CollectionModel->>Database: Multiple product queries...
    end
    
    CollectionModel-->>CollectionController: Collections with products
    CollectionController-->>Frontend: Collection list
    Frontend-->>User: Display collections

    Note over User,Database: User Attempts Collection Access

    User->>Frontend: Click on collection
    Frontend->>Auth: Verify user token
    Auth->>UserController: GET /api/users/collections/:id
    
    rect rgb(253, 203, 110)
        Note over UserController: ⚠️ OVERSIZED CONTROLLER (1,898 lines)
        UserController->>UserModel: findById(userId)
        UserModel->>Database: Get user with embedded arrays
    end
    
    Database-->>UserModel: User with all embedded collections
    UserModel->>UserModel: Check assignedCollections array
    
    alt User has access
        UserModel-->>UserController: Access granted
        UserController->>UserModel: Update accessedCollections
        UserModel->>Database: Save user document
        Database-->>UserModel: Updated user
        UserController->>CollectionController: getCollectionById(id)
        CollectionController->>CollectionModel: findById(id).populate('products')
        CollectionModel->>Database: Get collection with products
        Database-->>CollectionModel: Collection data
        CollectionModel-->>CollectionController: Full collection
        UserController-->>Frontend: Collection content
        Frontend-->>User: Show collection
    else User lacks access
        UserModel-->>UserController: Access denied
        UserController-->>Frontend: 403 - Access denied
        Frontend-->>User: Show access denied message
    end
```

## ONE-TIME CODE FLOW

```mermaid
sequenceDiagram
    participant Admin
    participant User
    participant Frontend
    participant OneTimeCodeController
    participant OneTimeCodeModel
    participant MessageTemplate
    participant WhatsApp
    participant Database

    Note over Admin,Database: Admin Creates One-Time Code

    Admin->>Frontend: Create one-time code
    Frontend->>OneTimeCodeController: POST /api/one-time-codes
    OneTimeCodeController->>OneTimeCodeController: Generate 6-digit code
    OneTimeCodeController->>OneTimeCodeModel: create({ code, expiresAt, purpose })
    OneTimeCodeModel->>Database: Save new code
    Database-->>OneTimeCodeModel: Code created
    
    OneTimeCodeController->>MessageTemplate: getTemplate(type)
    MessageTemplate->>Database: findOne({ type: 'whatsapp' })
    Database-->>MessageTemplate: Template data
    MessageTemplate-->>OneTimeCodeController: Message template
    
    OneTimeCodeController->>WhatsApp: Send message with code
    WhatsApp-->>OneTimeCodeController: Message sent
    OneTimeCodeController-->>Frontend: Code created successfully
    Frontend-->>Admin: Show success message

    Note over Admin,Database: User Uses One-Time Code

    User->>Frontend: Enter received code
    Frontend->>OneTimeCodeController: POST /api/one-time-codes/verify
    OneTimeCodeController->>OneTimeCodeModel: findOne({ code, isUsed: false })
    OneTimeCodeModel->>Database: Query for valid code
    
    alt Code exists and valid
        Database-->>OneTimeCodeModel: Valid code found
        OneTimeCodeModel->>OneTimeCodeModel: Check expiration
        
        alt Code not expired
            OneTimeCodeModel-->>OneTimeCodeController: Code valid
            OneTimeCodeController->>OneTimeCodeModel: Update isUsed and usedAt
            OneTimeCodeModel->>Database: Mark code as used
            Database-->>OneTimeCodeModel: Code updated
            
            alt Code grants collection access
                OneTimeCodeController->>OneTimeCodeController: Get allowed collections
                OneTimeCodeController->>Frontend: POST /api/users/assign-collections
                Frontend->>OneTimeCodeController: Assign collections to user
                OneTimeCodeController-->>Frontend: Collections assigned
            end
            
            OneTimeCodeController-->>Frontend: 200 - Code verified successfully
            Frontend-->>User: Access granted / Success message
        else Code expired
            OneTimeCodeModel-->>OneTimeCodeController: Code expired
            OneTimeCodeController-->>Frontend: 400 - Code expired
            Frontend-->>User: Code expired message
        end
    else Code invalid
        Database-->>OneTimeCodeModel: No valid code found
        OneTimeCodeModel-->>OneTimeCodeController: Invalid code
        OneTimeCodeController-->>Frontend: 400 - Invalid code
        Frontend-->>User: Invalid code message
    end
```

## COLLECTION MANAGEMENT FLOW

```mermaid
sequenceDiagram
    participant Admin
    participant Frontend
    participant Auth
    participant CollectionController
    participant CollectionModel
    participant ProductModel
    participant Cloudinary
    participant Database

    Note over Admin,Database: Create Collection Flow

    Admin->>Frontend: Create new collection
    Frontend->>Auth: Verify admin token
    Auth->>CollectionController: POST /api/collections

    rect rgb(253, 203, 110)
        Note over CollectionController: ⚠️ OVERSIZED FILE (1,074 lines)
        CollectionController->>CollectionController: Validate collection data
        CollectionController->>Cloudinary: Upload collection image
    end

    Cloudinary-->>CollectionController: Image URL
    CollectionController->>CollectionModel: create(collectionData)
    CollectionModel->>Database: Save new collection
    Database-->>CollectionModel: Collection created

    alt Has parent collection
        CollectionModel->>CollectionModel: findById(parentId)
        CollectionModel->>Database: Get parent collection
        Database-->>CollectionModel: Parent collection
        CollectionModel->>CollectionModel: Update parent's subCollections
        CollectionModel->>Database: Save parent collection
    end

    CollectionModel-->>CollectionController: New collection
    CollectionController-->>Frontend: 201 - Collection created
    Frontend-->>Admin: Show success message

    Note over Admin,Database: Add Products to Collection

    Admin->>Frontend: Add products to collection
    Frontend->>CollectionController: POST /api/collections/:id/products
    CollectionController->>ProductModel: find({ _id: { $in: productIds } })
    ProductModel->>Database: Get selected products
    Database-->>ProductModel: Product list
    ProductModel-->>CollectionController: Products validated

    CollectionController->>CollectionModel: findByIdAndUpdate(collectionId)
    CollectionModel->>Database: Add products to collection
    Database-->>CollectionModel: Updated collection
    CollectionModel-->>CollectionController: Collection with products
    CollectionController-->>Frontend: Products added successfully
    Frontend-->>Admin: Show updated collection

    Note over Admin,Database: Collection Analytics Request

    Admin->>Frontend: View collection analytics
    Frontend->>CollectionController: GET /api/collections/:id/analytics
    
    rect rgb(255, 107, 107)
        Note over CollectionController,Database: ⚠️ N+1 QUERY PROBLEM
        CollectionController->>CollectionModel: findById(collectionId)
        CollectionModel->>Database: Get collection
        Database-->>CollectionModel: Collection data
        
        CollectionController->>CollectionController: Loop through users
        loop For each user with access
            CollectionController->>Database: Get user access data
            Database-->>CollectionController: User access info
        end
    end
    
    CollectionController->>CollectionController: Calculate analytics
    CollectionController-->>Frontend: Analytics data
    Frontend-->>Admin: Display analytics dashboard
```

## ORDER PROCESSING FLOW

```mermaid
sequenceDiagram
    participant Customer
    participant Frontend
    participant Auth
    participant OrderController
    participant ProductController
    participant PayPal
    participant OrderModel
    participant Database

    Note over Customer,Database: Order Creation Flow

    Customer->>Frontend: Add items to cart
    Frontend->>Customer: Show cart summary
    Customer->>Frontend: Proceed to checkout
    Frontend->>Auth: Verify user token
    Auth->>OrderController: POST /api/orders
    
    OrderController->>ProductController: Validate product availability
    ProductController->>Database: Check product stock/status
    Database-->>ProductController: Product validation
    ProductController-->>OrderController: Products valid
    
    OrderController->>OrderController: Calculate prices (tax, shipping)
    OrderController->>OrderModel: create(orderData)
    OrderModel->>Database: Save pending order
    Database-->>OrderModel: Order created
    OrderModel-->>OrderController: Order with ID
    OrderController-->>Frontend: Order created - pending payment
    Frontend-->>Customer: Show payment options

    Note over Customer,Database: Payment Processing

    Customer->>Frontend: Select PayPal payment
    Frontend->>PayPal: Initialize payment
    PayPal-->>Frontend: Payment approval URL
    Frontend-->>Customer: Redirect to PayPal
    Customer->>PayPal: Complete payment
    PayPal->>Frontend: Payment confirmation
    
    Frontend->>OrderController: PUT /api/orders/:id/pay
    OrderController->>PayPal: Verify payment details
    PayPal-->>OrderController: Payment verified
    
    OrderController->>OrderModel: updateOne({ isPaid: true, paidAt: Date.now() })
    OrderModel->>Database: Update order status
    Database-->>OrderModel: Order updated
    OrderModel-->>OrderController: Payment confirmed
    OrderController-->>Frontend: Payment successful
    Frontend-->>Customer: Show order confirmation

    Note over Customer,Database: Order Fulfillment

    Admin->>Frontend: View pending orders
    Frontend->>OrderController: GET /api/orders
    OrderController->>OrderModel: find({ isPaid: true, isDelivered: false })
    OrderModel->>Database: Get paid pending orders
    Database-->>OrderModel: Order list
    OrderModel-->>OrderController: Pending orders
    OrderController-->>Frontend: Orders to fulfill
    Frontend-->>Admin: Show fulfillment dashboard
    
    Admin->>Frontend: Mark order as delivered
    Frontend->>OrderController: PUT /api/orders/:id/deliver
    OrderController->>OrderModel: updateOne({ isDelivered: true, deliveredAt: Date.now() })
    OrderModel->>Database: Update delivery status
    Database-->>OrderModel: Order updated
    OrderController-->>Frontend: Order marked as delivered
    Frontend-->>Admin: Show confirmation
```

## CURRENT API PERFORMANCE ISSUES

```mermaid
graph TD
    subgraph "Request Performance Problems"
        P1[Authentication: 200ms<br/>JWT verification + DB lookup]
        P2[User Collections: 300ms<br/>Embedded array scanning]
        P3[Collection List: 250ms<br/>N+1 product queries]
        P4[User Profile: 150ms<br/>Full document retrieval]
        P5[Order History: 200ms<br/>No pagination, full scan]
    end

    subgraph "Database Query Issues"
        D1[No Indexes on Frequent Queries]
        D2[Full Document Retrieval]
        D3[Embedded Array Scanning]
        D4[N+1 Query Patterns]
        D5[No Query Result Caching]
    end

    subgraph "Controller Complexity"
        C1[userController.js: 1,898 lines]
        C2[collectionController.js: 1,074 lines]
        C3[Mixed Business Logic]
        C4[No Separation of Concerns]
    end

    P1 --> D1
    P2 --> D3
    P3 --> D4
    P4 --> D2
    P5 --> D1

    C1 --> P1
    C1 --> P2
    C1 --> P4
    C2 --> P3
    C3 --> P1
    C4 --> P2

    classDef performance fill:#ff6b6b,stroke:#d63031,stroke-width:2px,color:#fff
    classDef database fill:#fdcb6e,stroke:#e17055,stroke-width:2px
    classDef controller fill:#fd79a8,stroke:#e84393,stroke-width:2px,color:#fff

    class P1,P2,P3,P4,P5 performance
    class D1,D2,D3,D4,D5 database
    class C1,C2,C3,C4 controller
```

## OPTIMIZED API FLOW (PROPOSED)

```mermaid
sequenceDiagram
    participant Client
    participant AuthService
    participant UserService
    participant CollectionService
    participant Cache
    participant Database

    Note over Client,Database: Optimized Collection Access Flow

    Client->>AuthService: Request with JWT
    AuthService->>Cache: Check token cache
    
    alt Token in cache
        Cache-->>AuthService: Valid user data
    else Token not cached
        AuthService->>Database: Verify token + get user
        Database-->>AuthService: User data
        AuthService->>Cache: Cache user data (5min TTL)
    end
    
    AuthService->>CollectionService: getUserCollections(userId)
    CollectionService->>Cache: Check collections cache
    
    alt Collections cached
        Cache-->>CollectionService: Cached collections
    else Not cached
        CollectionService->>Database: Aggregation query with indexes
        Database-->>CollectionService: Collections with products (50ms)
        CollectionService->>Cache: Cache result (10min TTL)
    end
    
    CollectionService-->>Client: Collections (Total: 100ms vs 500ms)

    Note over Client,Database: Benefits of Optimization

    rect rgb(0, 184, 148)
        Note over Client,Database: 80% Performance Improvement
        Note over AuthService: Service Layer Separation
        Note over Cache: Redis Caching Layer
        Note over Database: Proper Indexes + Aggregation
    end
```

This comprehensive API flow documentation shows current bottlenecks and the path to optimization through proper architecture and caching strategies. 