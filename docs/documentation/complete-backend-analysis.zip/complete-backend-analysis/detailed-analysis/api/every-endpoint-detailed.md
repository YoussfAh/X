# COMPLETE API ENDPOINT DOCUMENTATION

## API OVERVIEW

**Base URL**: `/api`  
**Authentication**: JWT (HTTP-only cookies or Bearer token)  
**Content-Type**: `application/json`  
**Framework**: Express.js 4.18.2

---

## AUTHENTICATION & USER MANAGEMENT APIs

### User Authentication Endpoints

#### POST /api/users/auth
**Purpose**: User login authentication  
**Access**: Public  
**Controller**: `userController.authUser`

**Request Body:**
```javascript
{
  email: String (required, email format)
  password: String (required, min 6 chars)
}
```

**Response (Success 200):**
```javascript
{
  _id: ObjectId
  name: String
  email: String
  isAdmin: Boolean
  age: Number
  fitnessGoal: String
  injuries: String
  additionalInfo: String
  whatsAppPhoneNumber: String
  instagramUsername: String
  facebookProfile: String
  twitterUsername: String
  carouselSlides: Array
  lockedCollections: Array
  accessedCollections: Array
  assignedCollections: Array
  sessionId: String
}
```

**Security Features:**
- Device-based login attempt tracking
- Progressive delays for failed attempts
- Account lockout after 15 failed attempts
- IP-based registration rate limiting
- JWT token with HTTP-only cookie

**Error Responses:**
- `401`: Invalid credentials
- `429`: Too many login attempts (device locked)

#### POST /api/users (Register)
**Purpose**: User registration  
**Access**: Public  
**Controller**: `userController.registerUser`

**Request Body:**
```javascript
{
  name: String (required)
  email: String (required, unique)
  password: String (required, min 6 chars)
  age: Number (optional)
  fitnessGoal: String (optional)
  injuries: String (optional)
  additionalInfo: String (optional)
  whatsAppPhoneNumber: String (optional)
}
```

**Rate Limiting**: 3 registrations per hour per IP

**Response (Success 201):**
```javascript
{
  _id: ObjectId
  name: String
  email: String
  isAdmin: Boolean
  age: Number
  fitnessGoal: String
  // ... other user fields
}
```

#### POST /api/users/logout
**Purpose**: User logout  
**Access**: Public  
**Controller**: `userController.logoutUser`

**Response (Success 200):**
```javascript
{
  message: "Logged out successfully"
}
```

**Action**: Clears JWT cookie

---

### User Profile Management

#### GET /api/users/profile
**Purpose**: Get current user profile  
**Access**: Private (protect middleware)  
**Controller**: `userController.getUserProfile`

**Response (Success 200):**
```javascript
{
  _id: ObjectId
  name: String
  email: String
  isAdmin: Boolean
  age: Number
  fitnessGoal: String
  injuries: String
  additionalInfo: String
  whatsAppPhoneNumber: String
  instagramUsername: String
  facebookProfile: String
  twitterUsername: String
  carouselSlides: Array
  lockedCollections: Array
  accessedCollections: Array
  assignedCollections: Array
  profileImage: String (Cloudinary URL)
  
  // Time frame information
  timeFrameStartDate: Date
  timeFrameDuration: Number
  timeFrameDurationType: String
  isWithinTimeFrame: Boolean
}
```

#### PUT /api/users/profile
**Purpose**: Update user profile  
**Access**: Private  
**Controller**: `userController.updateUserProfile`

**Request Body (Partial):**
```javascript
{
  name?: String
  email?: String
  password?: String
  age?: Number
  fitnessGoal?: String
  injuries?: String
  additionalInfo?: String
  whatsAppPhoneNumber?: String
  instagramUsername?: String
  facebookProfile?: String
  twitterUsername?: String
}
```

#### GET /api/users/refresh-data
**Purpose**: Refresh user data  
**Access**: Private  
**Controller**: `userController.refreshUserData`

#### GET /api/users/validate-session
**Purpose**: Validate JWT session (mobile support)  
**Access**: Private  
**Controller**: `userController.validateSession`

---

### Admin User Management

#### GET /api/users
**Purpose**: Get all users (admin only)  
**Access**: Private/Admin  
**Controller**: `userController.getUsers`

**Query Parameters:**
```javascript
{
  pageNumber?: Number (default: 1)
  keyword?: String (search by name/email)
  pageSize?: Number (default: 10)
}
```

**Response (Success 200):**
```javascript
{
  users: Array<UserObject>
  page: Number
  pages: Number
  totalUsers: Number
}
```

#### GET /api/users/stats
**Purpose**: Get user statistics for admin dashboard  
**Access**: Private/Admin  
**Controller**: `userController.getUserStats`

**Response (Success 200):**
```javascript
{
  totalUsers: Number
  activeUsers: Number
  adminUsers: Number
  newUsersThisMonth: Number
  usersWithTimeFrames: Number
  // Additional analytics data
}
```

#### GET /api/users/:id
**Purpose**: Get specific user by ID  
**Access**: Private/Admin  
**Controller**: `userController.getUserById`  
**Middleware**: `checkObjectId`

#### PUT /api/users/:id
**Purpose**: Update user by ID  
**Access**: Private/Admin  
**Controller**: `userController.updateUser`

#### DELETE /api/users/:id
**Purpose**: Delete user by ID  
**Access**: Private/Admin  
**Controller**: `userController.deleteUser`

#### PUT /api/users/:id/update-password
**Purpose**: Admin update user password  
**Access**: Private/Admin  
**Controller**: `userController.adminUpdateUserPassword`

---

## COLLECTION MANAGEMENT APIs

### Public Collection Access

#### GET /api/collections
**Purpose**: Get collections based on user authentication  
**Access**: Public (but returns different data based on auth)  
**Controller**: `collectionController.getCollections`

**Response Structure:**
```javascript
{
  publicCollections: Array<Collection>
  assignedCollections: Array<Collection> // Only for authenticated users
  userInfo: {
    _id: ObjectId
    name: String
    isAdmin: Boolean
  } // null for unauthenticated users
}
```

**Business Logic:**
- Unauthenticated: Returns only public collections
- Admin users: Returns all collections
- Regular users: Returns public + assigned collections

#### GET /api/collections/:id
**Purpose**: Get specific collection details  
**Access**: Private  
**Controller**: `collectionController.getCollectionById`

**Response (Success 200):**
```javascript
{
  _id: ObjectId
  user: ObjectId
  name: String
  description: String
  image: String (Cloudinary URL)
  displayOrder: Number
  orderNumber: String
  accessCode: String
  requiresCode: Boolean
  isPublic: Boolean
  codeUpdatedAt: Date
  products: Array<{
    product: ProductObject
    displayOrder: Number
  }>
  parentCollection: ObjectId
  subCollections: Array<Collection>
}
```

### Admin Collection Management

#### GET /api/collections/admin
**Purpose**: Get all collections for admin management  
**Access**: Private/Admin  
**Controller**: `collectionController.getAdminCollections`

**Query Parameters:**
```javascript
{
  pageNumber?: Number
  keyword?: String (search name/description)
  visibility?: String ("public" | "private")
  skipPagination?: Boolean
}
```

#### POST /api/collections
**Purpose**: Create new collection  
**Access**: Private/Admin  
**Controller**: `collectionController.createCollection`

**Request Body:**
```javascript
{
  name: String (required)
  description: String (required)
  image: String (required, Cloudinary URL)
  displayOrder?: Number
  orderNumber?: String
  requiresCode?: Boolean
  isPublic?: Boolean (default: true)
  products?: Array<{
    product: ObjectId
    displayOrder?: Number
  }>
  parentCollection?: ObjectId
}
```

#### PUT /api/collections/:id
**Purpose**: Update collection  
**Access**: Private/Admin  
**Controller**: `collectionController.updateCollection`

#### DELETE /api/collections/:id
**Purpose**: Delete collection  
**Access**: Private/Admin  
**Controller**: `collectionController.deleteCollection`

**Cascade Action**: Removes related one-time codes

---

## ASSIGNED COLLECTIONS APIs

#### GET /api/users/:id/assigned-collections
**Purpose**: Get user's assigned collections  
**Access**: Private/Admin  
**Controller**: `userController.getUserAssignedCollections`

#### POST /api/users/:id/assigned-collections
**Purpose**: Assign collection to user  
**Access**: Private/Admin  
**Controller**: `userController.adminAssignCollection`

**Request Body:**
```javascript
{
  collectionId: ObjectId (required)
  notes?: String
  tags?: Array<String>
}
```

#### POST /api/users/:id/assigned-collections/batch
**Purpose**: Batch assign multiple collections  
**Access**: Private/Admin  
**Controller**: `userController.batchAssignCollections`

**Request Body:**
```javascript
{
  collectionIds: Array<ObjectId> (required)
  notes?: String
  tags?: Array<String>
}
```

#### PUT /api/users/:id/assigned-collections/:collectionId
**Purpose**: Update assigned collection metadata  
**Access**: Private/Admin  
**Controller**: `userController.updateAssignedCollection`

#### DELETE /api/users/:id/assigned-collections/:collectionId
**Purpose**: Remove assigned collection  
**Access**: Private/Admin  
**Controller**: `userController.adminRemoveAssignedCollection`

#### POST /api/users/:id/assigned-collections/:collectionId/access
**Purpose**: Track collection access  
**Access**: Private  
**Controller**: `userController.trackCollectionAccess`

---

## ONE-TIME CODE MANAGEMENT APIs

### Code Generation

#### POST /api/one-time-codes/generate
**Purpose**: Generate single access code  
**Access**: Private/Admin  
**Controller**: `oneTimeCodeController.generateOneTimeCode`

**Request Body:**
```javascript
{
  collectionId: ObjectId (required)
  expiryDays?: Number (default: 30)
  maxUses?: Number (default: 1, max: 1000)
}
```

**Response (Success 201):**
```javascript
{
  _id: ObjectId
  code: String (6-char hex, uppercase)
  collectionId: ObjectId
  collectionName: String
  createdBy: ObjectId
  expiresAt: Date
  maxUses: Number
  currentUses: Number
  isUniversal: Boolean
  createdAt: Date
  updatedAt: Date
}
```

#### POST /api/one-time-codes/batch-generate
**Purpose**: Generate multiple codes for collection  
**Access**: Private/Admin  
**Controller**: `oneTimeCodeController.generateBatchCodes`

**Request Body:**
```javascript
{
  collectionId: ObjectId (required)
  quantity: Number (required, 1-100)
  expiryDays?: Number (default: 30)
  maxUses?: Number (default: 1)
}
```

**Response (Success 201):**
```javascript
{
  success: Boolean
  count: Number
  codes: Array<OneTimeCodeObject>
}
```

#### POST /api/one-time-codes/generate-universal
**Purpose**: Generate universal access code (works for all collections)  
**Access**: Private/Admin  
**Controller**: `oneTimeCodeController.generateUniversalCode`

**Request Body:**
```javascript
{
  expiryDays?: Number (default: 30)
  maxUses?: Number (default: 1)
}
```

**Code Format**: `U-XXXXXX` (prefix indicates universal)

#### POST /api/one-time-codes/batch-generate-universal
**Purpose**: Generate multiple universal codes  
**Access**: Private/Admin  
**Controller**: `oneTimeCodeController.generateBatchUniversalCodes`

### Code Usage

#### POST /api/one-time-codes/use
**Purpose**: Use/redeem access code  
**Access**: Private  
**Controller**: `oneTimeCodeController.useOneTimeCode`

**Request Body:**
```javascript
{
  code: String (required)
}
```

**Business Logic:**
1. Validates code exists and is available
2. Checks expiration date
3. Verifies usage limits
4. Adds collection to user's accessed collections
5. Records usage history with IP and user agent
6. Increments usage counter

**Response (Success 200):**
```javascript
{
  success: Boolean
  message: String
  collection: CollectionObject
  usesRemaining: Number
}
```

**Error Responses:**
- `404`: Code not found
- `400`: Code expired or fully used
- `409`: Collection already accessed by user

### Code Management

#### GET /api/one-time-codes
**Purpose**: List all generated codes (admin)  
**Access**: Private/Admin  
**Controller**: `oneTimeCodeController.getOneTimeCodes`

**Query Parameters:**
```javascript
{
  pageNumber?: Number
  collectionId?: ObjectId (filter by collection)
  isUsed?: Boolean (filter by usage status)
  isExpired?: Boolean (filter by expiration)
}
```

#### GET /api/one-time-codes/:id
**Purpose**: Get specific code details  
**Access**: Private/Admin  
**Controller**: `oneTimeCodeController.getOneTimeCodeById`

#### DELETE /api/one-time-codes/:id
**Purpose**: Delete/revoke access code  
**Access**: Private/Admin  
**Controller**: `oneTimeCodeController.deleteOneTimeCode`

---

## PRODUCT MANAGEMENT APIs

#### GET /api/products
**Purpose**: Get all products  
**Access**: Public  
**Controller**: `productController.getProducts`

**Query Parameters:**
```javascript
{
  pageNumber?: Number
  keyword?: String (search name/description)
  category?: String
}
```

#### GET /api/products/:id
**Purpose**: Get specific product  
**Access**: Public  
**Controller**: `productController.getProductById`

#### POST /api/products
**Purpose**: Create new product  
**Access**: Private/Admin  
**Controller**: `productController.createProduct`

**Request Body:**
```javascript
{
  name: String (required)
  image: String (required, Cloudinary URL)
  category: String (required)
  description: String (required)
  youtubeVideo?: String
  isMealDiet?: Boolean
}
```

#### PUT /api/products/:id
**Purpose**: Update product  
**Access**: Private/Admin  
**Controller**: `productController.updateProduct`

#### DELETE /api/products/:id
**Purpose**: Delete product  
**Access**: Private/Admin  
**Controller**: `productController.deleteProduct`

#### POST /api/products/:id/reviews
**Purpose**: Add product review  
**Access**: Private  
**Controller**: `productController.createProductReview`

**Request Body:**
```javascript
{
  rating: Number (required, 1-5)
  comment: String (required)
}
```

---

## ORDER MANAGEMENT APIs

#### GET /api/orders
**Purpose**: Get user orders  
**Access**: Private  
**Controller**: `orderController.getMyOrders`

#### GET /api/orders/:id
**Purpose**: Get specific order  
**Access**: Private  
**Controller**: `orderController.getOrderById`

#### POST /api/orders
**Purpose**: Create new order  
**Access**: Private  
**Controller**: `orderController.addOrderItems`

**Request Body:**
```javascript
{
  orderItems: Array<{
    name: String
    qty: Number
    image: String
    price: Number
    product: ObjectId
  }>
  shippingAddress: {
    address: String
    city: String
    postalCode: String
    country: String
  }
  paymentMethod: String
  itemsPrice: Number
  taxPrice: Number
  shippingPrice: Number
  totalPrice: Number
}
```

#### PUT /api/orders/:id/pay
**Purpose**: Update order to paid  
**Access**: Private  
**Controller**: `orderController.updateOrderToPaid`

#### PUT /api/orders/:id/deliver
**Purpose**: Update order to delivered (admin)  
**Access**: Private/Admin  
**Controller**: `orderController.updateOrderToDelivered`

#### GET /api/orders (Admin)
**Purpose**: Get all orders (admin)  
**Access**: Private/Admin  
**Controller**: `orderController.getOrders`

---

## FILE UPLOAD APIs

#### POST /api/upload
**Purpose**: Upload image to Cloudinary  
**Access**: Private/Admin  
**Controller**: `uploadController.uploadImage`

**Request**: Multipart form data with image file

**Response (Success 200):**
```javascript
{
  message: String
  image: String (Cloudinary URL)
}
```

---

## MESSAGE TEMPLATE APIs

#### GET /api/message-templates
**Purpose**: Get all message templates  
**Access**: Private/Admin  
**Controller**: `messageTemplateController.getMessageTemplates`

#### POST /api/message-templates
**Purpose**: Create new message template  
**Access**: Private/Admin  
**Controller**: `messageTemplateController.createMessageTemplate`

**Request Body:**
```javascript
{
  name: String (required, unique)
  content: String (required)
  variables?: Array<String>
  category?: String
  isActive?: Boolean
}
```

#### PUT /api/message-templates/:id
**Purpose**: Update message template  
**Access**: Private/Admin  
**Controller**: `messageTemplateController.updateMessageTemplate`

#### DELETE /api/message-templates/:id
**Purpose**: Delete message template  
**Access**: Private/Admin  
**Controller**: `messageTemplateController.deleteMessageTemplate`

---

## WORKOUT TRACKING APIs

#### GET /api/workout/entries
**Purpose**: Get user workout entries  
**Access**: Private  
**Controller**: `workoutController.getWorkoutEntries`

#### POST /api/workout/entries
**Purpose**: Create workout entry  
**Access**: Private  
**Controller**: `workoutController.createWorkoutEntry`

**Request Body:**
```javascript
{
  workoutDate: Date (required)
  exercises: Array<{
    name: String
    sets: Number
    reps: Number
    weight?: Number
    duration?: Number
  }>
  totalDuration: Number
  caloriesBurned?: Number
  notes?: String
  moodRating?: Number (1-10)
  difficultyRating?: Number (1-10)
}
```

---

## SYSTEM SETTINGS APIs

#### GET /api/system-settings
**Purpose**: Get system settings  
**Access**: Private/Admin  
**Controller**: `systemSettingsController.getSystemSettings`

#### PUT /api/system-settings
**Purpose**: Update system settings  
**Access**: Private/Admin  
**Controller**: `systemSettingsController.updateSystemSettings`

---

## TIME FRAME MANAGEMENT APIs

#### POST /api/users/:id/timeframe
**Purpose**: Set user time frame  
**Access**: Private/Admin  
**Controller**: `userController.saveTimeFrameSettings`

**Request Body:**
```javascript
{
  startDate: Date (required)
  duration: Number (required)
  durationType: String (required, "days" | "months")
  notes?: String
}
```

#### GET /api/users/:id/timeframe/history
**Purpose**: Get user time frame history  
**Access**: Private/Admin  
**Controller**: `userController.getTimeFrameHistory`

#### GET /api/users/timeframe/management
**Purpose**: Get time frame management overview  
**Access**: Private/Admin  
**Controller**: `userController.getTimeFrameManagement`

---

## CONTACT TRACKING APIs

#### POST /api/users/:id/contact
**Purpose**: Track user contact  
**Access**: Private/Admin  
**Controller**: `userController.trackUserContact`

**Request Body:**
```javascript
{
  contactType: String (required)
  method: String (required)
  notes: String
  followUpDate?: Date
}
```

#### GET /api/users/:id/contact-history
**Purpose**: Get user contact history  
**Access**: Private/Admin  
**Controller**: `userController.getUserContactHistory`

#### PUT /api/users/:id/contact-history/:contactId
**Purpose**: Update contact entry  
**Access**: Private/Admin  
**Controller**: `userController.updateContactEntry`

#### DELETE /api/users/:id/contact-history/:contactId
**Purpose**: Delete contact entry  
**Access**: Private/Admin  
**Controller**: `userController.deleteContactEntry`

#### GET /api/users/contact-follow-ups
**Purpose**: Get global contact follow-ups  
**Access**: Private/Admin  
**Controller**: `userController.getContactFollowUps`

---

## WHATSAPP INTEGRATION APIs

#### POST /api/users/:id/whatsapp-contact
**Purpose**: Send WhatsApp message to user  
**Access**: Private/Admin  
**Controller**: `userController.sendWhatsAppContact`

**Request Body:**
```javascript
{
  message: String (required)
  templateId?: ObjectId
  variables?: Object
}
```

---

## MAINTENANCE & CLEANUP APIs

#### DELETE /api/users/cleanup-regular-users
**Purpose**: Clean up inactive regular users  
**Access**: Private/Admin  
**Controller**: `userController.cleanupRegularUsers`

---

## ERROR HANDLING

### Standard Error Response Format:
```javascript
{
  message: String (error description)
  stack?: String (development only)
}
```

### HTTP Status Codes Used:
- `200`: Success
- `201`: Created
- `400`: Bad Request
- `401`: Unauthorized
- `403`: Forbidden
- `404`: Not Found
- `409`: Conflict
- `429`: Too Many Requests
- `500`: Internal Server Error

### Common Error Scenarios:
1. **Authentication Errors**: Invalid JWT, expired token
2. **Authorization Errors**: Insufficient permissions
3. **Validation Errors**: Invalid input data
4. **Resource Errors**: Not found, already exists
5. **Rate Limiting**: Too many requests
6. **Server Errors**: Database connection, internal errors

---

## MIDDLEWARE ANALYSIS

### protect Middleware
- Validates JWT token from cookie or Authorization header
- Attaches user object to request
- Handles token expiration and invalid tokens

### admin Middleware
- Requires protect middleware first
- Validates user.isAdmin === true
- Supports admin level checking

### checkObjectId Middleware
- Validates MongoDB ObjectId parameters
- Returns 404 for invalid ObjectIds

### asyncHandler Middleware
- Wraps async route handlers
- Automatically catches and forwards errors

This comprehensive API documentation covers every endpoint with complete request/response specifications, security requirements, and business logic details. 