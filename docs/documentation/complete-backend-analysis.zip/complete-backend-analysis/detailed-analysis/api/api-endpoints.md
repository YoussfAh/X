# API ENDPOINT ANALYSIS

## OVERVIEW
This document analyzes every API endpoint in the backend system.

## USER AUTHENTICATION ENDPOINTS

### POST /api/users/auth
- **Purpose**: User login
- **Controller**: userController.authUser
- **Security**: Device tracking, rate limiting
- **Response**: User data + JWT token

### POST /api/users (Register)
- **Purpose**: User registration  
- **Controller**: userController.registerUser
- **Security**: IP-based rate limiting
- **Limit**: 3 registrations per hour per IP

### POST /api/users/logout
- **Purpose**: Clear JWT cookie
- **Controller**: userController.logoutUser

## USER PROFILE ENDPOINTS

### GET /api/users/profile
- **Purpose**: Get current user profile
- **Middleware**: protect
- **Returns**: Complete user data

### PUT /api/users/profile  
- **Purpose**: Update user profile
- **Middleware**: protect

## COLLECTION ENDPOINTS

### GET /api/collections
- **Purpose**: Get collections (public + assigned)
- **Logic**: Different responses based on user auth level

### POST /api/collections
- **Purpose**: Create collection
- **Middleware**: protect, admin

## ONE-TIME CODE ENDPOINTS

### POST /api/one-time-codes/generate
- **Purpose**: Generate access codes
- **Middleware**: protect, admin

### POST /api/one-time-codes/use
- **Purpose**: Redeem access codes
- **Middleware**: protect

## ADMIN ENDPOINTS

### GET /api/users (Admin)
- **Purpose**: Get all users
- **Middleware**: protect, admin
- **Features**: Pagination, search

### POST /api/users/:id/assigned-collections
- **Purpose**: Assign collections to users
- **Middleware**: protect, admin

This covers the main API endpoints with their security and functionality. 