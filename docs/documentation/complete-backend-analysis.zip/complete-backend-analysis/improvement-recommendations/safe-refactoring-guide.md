# SAFE REFACTORING GUIDE - NO ERRORS APPROACH

## ⚠️ CRITICAL: FOLLOW THIS EXACT ORDER TO AVOID BREAKING THE APPLICATION

This guide provides a step-by-step approach that AI tools can follow safely without causing errors or breaking functionality.

---

## PHASE 1: PREPARATION (WEEK 1) - ZERO RISK

### Step 1.1: Create Backup Points
```bash
# Create backup branch
git checkout -b refactoring-backup
git push origin refactoring-backup

# Create working branch
git checkout main
git checkout -b safe-refactoring
```

### Step 1.2: Add Testing Framework FIRST
```bash
# Install testing dependencies
npm install --save-dev jest@^29.0.0 supertest@^6.3.0 mongodb-memory-server@^8.0.0
```

Create `jest.config.js`:
```javascript
export default {
  testEnvironment: 'node',
  transform: {},
  extensionsToTreatAsEsm: ['.js'],
  moduleNameMapping: {
    '^(\\.{1,2}/.*)\\.js$': '$1'
  }
};
```

### Step 1.3: Test Current Functionality BEFORE ANY CHANGES
Create `tests/current-functionality.test.js`:
```javascript
import request from 'supertest';
import app from '../server.js';

describe('Current System Tests - DO NOT MODIFY', () => {
  test('Server health check', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
  });

  test('User registration endpoint exists', async () => {
    const response = await request(app)
      .post('/api/users/register')
      .send({
        name: 'Test User',
        email: 'test@example.com', 
        password: 'password123'
      });
    // Should not be 404 - endpoint exists
    expect(response.status).not.toBe(404);
  });

  test('User login endpoint exists', async () => {
    const response = await request(app)
      .post('/api/users/auth')
      .send({
        email: 'test@example.com',
        password: 'password123'
      });
    // Should not be 404 - endpoint exists  
    expect(response.status).not.toBe(404);
  });
});
```

**RUN TESTS BEFORE ANY CHANGES:**
```bash
npm test
```

All tests must pass before proceeding!

---

## PHASE 2: SAFE DECOMPOSITION (WEEK 2-3) - LOW RISK

### Step 2.1: Create New Controller Files (NO CHANGES TO EXISTING)

**🚨 RULE: Never modify existing files in this step - only create new ones**

Create `controllers/authController.js` (NEW FILE):
```javascript
import asyncHandler from '../middleware/asyncHandler.js';
import generateToken from '../utils/generateToken.js';
import User from '../models/userModel.js';

// @desc    Auth user & get token
// @route   POST /api/users/auth
// @access  Public
const authUser = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email });

  if (user && (await user.matchPassword(password))) {
    generateToken(res, user._id);

    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
    });
  } else {
    res.status(401);
    throw new Error('Invalid email or password');
  }
});

// @desc    Register a new user
// @route   POST /api/users/register
// @access  Public
const registerUser = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;

  const userExists = await User.findOne({ email });

  if (userExists) {
    res.status(400);
    throw new Error('User already exists');
  }

  const user = await User.create({
    name,
    email,
    password,
  });

  if (user) {
    generateToken(res, user._id);

    res.status(201).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
    });
  } else {
    res.status(400);
    throw new Error('Invalid user data');
  }
});

// @desc    Logout user / clear cookie
// @route   POST /api/users/logout
// @access  Public
const logoutUser = (req, res) => {
  res.clearCookie('jwt');
  res.status(200).json({ message: 'Logged out successfully' });
};

export { authUser, registerUser, logoutUser };
```

Create `controllers/profileController.js` (NEW FILE):
```javascript
import asyncHandler from '../middleware/asyncHandler.js';
import User from '../models/userModel.js';

// @desc    Get user profile
// @route   GET /api/users/profile
// @access  Private
const getUserProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);

  if (user) {
    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
      whatsAppPhoneNumber: user.whatsAppPhoneNumber,
    });
  } else {
    res.status(404);
    throw new Error('User not found');
  }
});

// @desc    Update user profile
// @route   PUT /api/users/profile
// @access  Private
const updateUserProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);

  if (user) {
    user.name = req.body.name || user.name;
    user.email = req.body.email || user.email;

    if (req.body.password) {
      user.password = req.body.password;
    }

    const updatedUser = await user.save();

    res.json({
      _id: updatedUser._id,
      name: updatedUser.name,
      email: updatedUser.email,
      isAdmin: updatedUser.isAdmin,
    });
  } else {
    res.status(404);
    throw new Error('User not found');
  }
});

export { getUserProfile, updateUserProfile };
```

### Step 2.2: Create New Route Files (NO CHANGES TO EXISTING)

Create `routes/authRoutes.js` (NEW FILE):
```javascript
import express from 'express';
import {
  authUser,
  registerUser,
  logoutUser,
} from '../controllers/authController.js';

const router = express.Router();

router.route('/register').post(registerUser);
router.post('/login', authUser);
router.post('/logout', logoutUser);

export default router;
```

Create `routes/profileRoutes.js` (NEW FILE):
```javascript
import express from 'express';
import {
  getUserProfile,
  updateUserProfile,
} from '../controllers/profileController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.route('/').get(protect, getUserProfile).put(protect, updateUserProfile);

export default router;
```

### Step 2.3: Test New Files Work
Add to `server.js` (ADD, don't replace):
```javascript
// Add these imports
import authRoutes from './routes/authRoutes.js';
import profileRoutes from './routes/profileRoutes.js';

// Add these routes ALONGSIDE existing ones
app.use('/api/auth', authRoutes);
app.use('/api/profile', profileRoutes);
```

Test new endpoints:
```bash
npm test

# Test new auth endpoints
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Test","email":"test@example.com","password":"password123"}'

# Test new profile endpoint  
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'
```

**ONLY PROCEED IF NEW ENDPOINTS WORK!**

---

## PHASE 3: GRADUAL MIGRATION (WEEK 4) - MEDIUM RISK

### Step 3.1: Update Routes ONE BY ONE

**🚨 CRITICAL: Only change ONE route at a time, test immediately**

In `routes/userRoutes.js`, replace ONE function at a time:

**BEFORE (userRoutes.js):**
```javascript
import {
  authUser,
  registerUser,
  logoutUser,
  getUserProfile,
  // ... other functions
} from '../controllers/userController.js';
```

**AFTER - Step 3.1a (Change only auth import):**
```javascript
import { authUser } from '../controllers/authController.js'; // NEW
import {
  registerUser,
  logoutUser,
  getUserProfile,
  // ... other functions
} from '../controllers/userController.js';
```

**TEST IMMEDIATELY:**
```bash
npm test
# Test specific endpoint
curl -X POST http://localhost:5000/api/users/auth \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'
```

**AFTER - Step 3.1b (Only if 3.1a works):**
```javascript
import { authUser, registerUser } from '../controllers/authController.js'; // NEW
import {
  logoutUser,
  getUserProfile,
  // ... other functions
} from '../controllers/userController.js';
```

**TEST IMMEDIATELY AFTER EACH CHANGE!**

### Step 3.2: Remove Functions from Original Controller GRADUALLY

**🚨 ONLY after all routes use new controllers**

In `controllers/userController.js`, comment out (don't delete) migrated functions:

```javascript
// COMMENTED OUT - MOVED TO authController.js
// const authUser = asyncHandler(async (req, res) => {
//   // ... function body
// });

// KEEP REMAINING FUNCTIONS UNTOUCHED
const someOtherFunction = asyncHandler(async (req, res) => {
  // ... keep as is
});
```

**TEST AFTER EACH COMMENTED FUNCTION:**
```bash
npm test
```

---

## PHASE 4: DATABASE OPTIMIZATION (WEEK 5) - MEDIUM RISK

### Step 4.1: Add Indexes WITHOUT Changing Schema

Create `scripts/addIndexes.js`:
```javascript
import mongoose from 'mongoose';
import dotenv from 'dotenv';

dotenv.config();

const addIndexes = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    
    // Add indexes ONE by ONE
    console.log('Adding user email index...');
    await mongoose.connection.collection('users').createIndex(
      { email: 1 }, 
      { unique: true, background: true }
    );
    
    console.log('Adding user isAdmin index...');
    await mongoose.connection.collection('users').createIndex(
      { isAdmin: 1 }, 
      { background: true }
    );
    
    console.log('✅ All indexes added successfully');
    process.exit(0);
  } catch (error) {
    console.error('❌ Error adding indexes:', error);
    process.exit(1);
  }
};

addIndexes();
```

Run indexes:
```bash
node scripts/addIndexes.js
```

**TEST AFTER ADDING INDEXES:**
```bash
npm test
```

---

## PHASE 5: TESTING ENHANCEMENT (WEEK 6) - LOW RISK

### Step 5.1: Add Comprehensive Tests

Create test files for each new controller:

`tests/controllers/authController.test.js`:
```javascript
import request from 'supertest';
import app from '../../server.js';

describe('Auth Controller', () => {
  test('POST /api/auth/register should work', async () => {
    const response = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Test User',
        email: 'testuser@example.com',
        password: 'password123'
      });
    
    expect(response.status).toBe(201);
    expect(response.body).toHaveProperty('_id');
  });

  test('POST /api/auth/login should work', async () => {
    // First register
    await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Login Test',
        email: 'login@example.com',
        password: 'password123'
      });

    // Then login
    const response = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'login@example.com',
        password: 'password123'
      });
    
    expect(response.status).toBe(200);
    expect(response.body.email).toBe('login@example.com');
  });
});
```

---

## CRITICAL SAFETY RULES

### ✅ DO's:
1. **Always create new files before modifying existing ones**
2. **Test after every single change**
3. **Change one route/function at a time**
4. **Keep backups of working code**
5. **Comment out rather than delete**
6. **Run full test suite after each phase**

### ❌ DON'Ts:
1. **Never modify multiple files simultaneously**
2. **Never change function names without updating all references**
3. **Never delete files until 100% sure they're not needed**
4. **Never skip testing steps**
5. **Never proceed if tests fail**

---

## ROLLBACK PROCEDURE (IF SOMETHING BREAKS)

### Step 1: Identify the Issue
```bash
# Run tests to see what failed
npm test

# Check specific endpoint
curl -X POST http://localhost:5000/api/users/auth \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'
```

### Step 2: Quick Rollback
```bash
# Go back to last working commit
git log --oneline -10
git checkout <last-working-commit-hash>

# Test to confirm it works
npm test
```

### Step 3: Fix and Resume
```bash
# Return to refactoring branch
git checkout safe-refactoring

# Fix the specific issue
# Re-run tests
npm test
```

---

## NAMING CONVENTIONS (AI-SAFE)

### Controller Files:
- `authController.js` - authentication functions
- `profileController.js` - user profile management
- `adminController.js` - admin-only functions
- `collectionController.js` - collection management

### Function Names (NEVER CHANGE THESE):
- Keep existing function names EXACTLY as they are
- Only move them between files
- Update imports/exports, not function names

### Route Patterns (SAFE TO ADD, RISKY TO CHANGE):
- Add new routes: `/api/auth/*`, `/api/profile/*`
- Keep existing routes: `/api/users/*` until migration complete
- Only remove old routes after 100% migration confirmed

---

## SUCCESS CRITERIA FOR EACH PHASE

### Phase 1 Complete When:
- [ ] All existing tests pass
- [ ] Backup branches created
- [ ] Testing framework working

### Phase 2 Complete When:
- [ ] New controller files created
- [ ] New routes working alongside old ones
- [ ] All tests still pass
- [ ] Both old and new endpoints work

### Phase 3 Complete When:
- [ ] All routes migrated to new controllers
- [ ] Old functions commented out (not deleted)
- [ ] All tests pass
- [ ] No broken endpoints

### Phase 4 Complete When:
- [ ] Database indexes added
- [ ] Query performance improved
- [ ] All tests pass
- [ ] No data corruption

### Phase 5 Complete When:
- [ ] Comprehensive test coverage added
- [ ] All new tests pass
- [ ] Documentation updated
- [ ] System fully validated

---

This guide ensures that AI tools can refactor safely without breaking the application by following incremental, testable steps. 