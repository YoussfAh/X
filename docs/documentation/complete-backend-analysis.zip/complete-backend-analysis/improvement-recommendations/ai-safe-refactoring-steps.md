# AI-SAFE REFACTORING STEPS

## ⚠️ CRITICAL WARNING FOR AI ASSISTANTS
**Follow these steps EXACTLY in order. Do NOT skip steps or modify multiple files at once.**

---

## PREPARATION PHASE (MANDATORY)

### Step 0: Create Safety Net
```bash
# Create backup branch FIRST
git checkout -b refactor-backup-$(date +%Y%m%d)
git push origin refactor-backup-$(date +%Y%m%d)

# Create working branch
git checkout -b safe-refactor-usercontroller
```

### Step 1: Add Testing Framework (MUST DO FIRST)
**Install dependencies:**
```bash
npm install --save-dev jest@^29.0.0 supertest@^6.3.0
```

**Create jest.config.js:**
```javascript
export default {
  testEnvironment: 'node',
  transform: {},
  extensionsToTreatAsEsm: ['.js'],
  moduleNameMapping: {
    '^(\\.{1,2}/.*)\\.js$': '$1'
  },
  testMatch: ['**/tests/**/*.test.js']
};
```

**Create tests/baseline.test.js:**
```javascript
import request from 'supertest';
import app from '../server.js';

describe('Baseline Tests - MUST PASS BEFORE ANY CHANGES', () => {
  test('Server starts successfully', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
  });

  test('User registration endpoint exists', async () => {
    const response = await request(app)
      .post('/api/users/register')
      .send({ name: 'Test', email: 'test@example.com', password: 'password123' });
    expect(response.status).not.toBe(404);
  });

  test('User auth endpoint exists', async () => {
    const response = await request(app)
      .post('/api/users/auth')
      .send({ email: 'test@example.com', password: 'wrongpassword' });
    expect(response.status).not.toBe(404);
  });
});
```

**RUN BASELINE TESTS:**
```bash
npm test
```
**⚠️ ALL TESTS MUST PASS BEFORE PROCEEDING**

---

## PHASE 1: CREATE NEW CONTROLLERS (DO NOT MODIFY EXISTING FILES)

### Step 2: Create authController.js (NEW FILE ONLY)

**Create controllers/authController.js:**
```javascript
import asyncHandler from '../middleware/asyncHandler.js';
import generateToken from '../utils/generateToken.js';
import User from '../models/userModel.js';

// @desc    Auth user & get token
// @route   POST /api/users/auth
// @access  Public
const authUser = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email });

  if (user && (await user.matchPassword(password))) {
    generateToken(res, user._id);

    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
    });
  } else {
    res.status(401);
    throw new Error('Invalid email or password');
  }
});

// @desc    Register a new user
// @route   POST /api/users/register
// @access  Public
const registerUser = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;

  const userExists = await User.findOne({ email });

  if (userExists) {
    res.status(400);
    throw new Error('User already exists');
  }

  const user = await User.create({
    name,
    email,
    password,
  });

  if (user) {
    generateToken(res, user._id);

    res.status(201).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
    });
  } else {
    res.status(400);
    throw new Error('Invalid user data');
  }
});

// @desc    Logout user / clear cookie
// @route   POST /api/users/logout
// @access  Public
const logoutUser = (req, res) => {
  res.clearCookie('jwt');
  res.status(200).json({ message: 'Logged out successfully' });
};

export { authUser, registerUser, logoutUser };
```

### Step 3: Create authRoutes.js (NEW FILE ONLY)

**Create routes/authRoutes.js:**
```javascript
import express from 'express';
import {
  authUser,
  registerUser,
  logoutUser,
} from '../controllers/authController.js';

const router = express.Router();

router.route('/register').post(registerUser);
router.post('/login', authUser);
router.post('/logout', logoutUser);

export default router;
```

### Step 4: Test New Auth Controller (BEFORE INTEGRATING)

**Add to server.js (ADD, don't replace existing routes):**
```javascript
// Add this import at the top with other imports
import authRoutes from './routes/authRoutes.js';

// Add this route AFTER existing routes (don't replace)
app.use('/api/auth', authRoutes);
```

**Test new endpoints:**
```bash
# Start server
npm run dev

# Test new auth endpoints in another terminal
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"newtest@example.com","password":"password123"}'

curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"newtest@example.com","password":"password123"}'
```

**⚠️ BOTH ENDPOINTS MUST WORK BEFORE PROCEEDING**

### Step 5: Run All Tests Again
```bash
npm test
```
**⚠️ ALL TESTS MUST STILL PASS**

---

## PHASE 2: GRADUAL MIGRATION (ONE ROUTE AT A TIME)

### Step 6: Migrate First Route Only

**In routes/userRoutes.js, change ONLY the auth import:**

**BEFORE:**
```javascript
import {
  authUser,
  registerUser,
  logoutUser,
  getUserProfile,
  // ... other functions
} from '../controllers/userController.js';
```

**AFTER (Change ONLY authUser import):**
```javascript
import { authUser } from '../controllers/authController.js';
import {
  registerUser,
  logoutUser,
  getUserProfile,
  // ... other functions
} from '../controllers/userController.js';
```

**Test immediately:**
```bash
npm test

# Test specific endpoint
curl -X POST http://localhost:5000/api/users/auth \
  -H "Content-Type: application/json" \
  -d '{"email":"newtest@example.com","password":"password123"}'
```

**⚠️ IF THIS FAILS, REVERT IMMEDIATELY:**
```bash
git checkout -- routes/userRoutes.js
```

### Step 7: Migrate Second Route (ONLY if Step 6 passed)

**In routes/userRoutes.js, add registerUser:**
```javascript
import { authUser, registerUser } from '../controllers/authController.js';
import {
  logoutUser,
  getUserProfile,
  // ... other functions
} from '../controllers/userController.js';
```

**Test immediately:**
```bash
npm test

curl -X POST http://localhost:5000/api/users/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Another Test","email":"another@example.com","password":"password123"}'
```

### Step 8: Migrate Third Route (ONLY if Step 7 passed)

**In routes/userRoutes.js, add logoutUser:**
```javascript
import { authUser, registerUser, logoutUser } from '../controllers/authController.js';
import {
  getUserProfile,
  // ... other functions
} from '../controllers/userController.js';
```

**Test immediately:**
```bash
npm test

curl -X POST http://localhost:5000/api/users/logout
```

---

## PHASE 3: CLEANUP (ONLY AFTER ALL MIGRATIONS WORK)

### Step 9: Comment Out Migrated Functions from userController.js

**⚠️ COMMENT OUT, DO NOT DELETE:**

```javascript
// MIGRATED TO authController.js - COMMENTED OUT FOR SAFETY
// const authUser = asyncHandler(async (req, res) => {
//   const { email, password } = req.body;
//   // ... rest of function
// });

// const registerUser = asyncHandler(async (req, res) => {
//   const { name, email, password } = req.body;
//   // ... rest of function
// });

// const logoutUser = (req, res) => {
//   res.clearCookie('jwt');
//   // ... rest of function
// };

// Keep all other functions unchanged
const getUserProfile = asyncHandler(async (req, res) => {
  // ... keep this
});
```

**Test after commenting out:**
```bash
npm test
```

**⚠️ IF TESTS FAIL, UNCOMMENT IMMEDIATELY**

---

## PHASE 4: CREATE SECOND CONTROLLER

### Step 10: Create profileController.js

**Follow the same pattern as authController:**

1. Create `controllers/profileController.js` with profile-related functions
2. Create `routes/profileRoutes.js`
3. Add to server.js as new route
4. Test new routes work
5. Gradually migrate existing routes
6. Comment out old functions

---

## ROLLBACK PROCEDURES

### If Step Fails - Immediate Rollback
```bash
# Revert specific file
git checkout -- [filename]

# Test that revert worked
npm test
```

### If Multiple Steps Fail - Full Rollback
```bash
# Go back to backup branch
git checkout refactor-backup-$(date +%Y%m%d)

# Verify everything works
npm test
```

### If Need to Start Over
```bash
# Delete failed branch
git branch -D safe-refactor-usercontroller

# Start fresh
git checkout main
git checkout -b safe-refactor-usercontroller-v2
```

---

## VALIDATION CHECKLIST

### After Each Step:
- [ ] `npm test` passes
- [ ] All existing endpoints still work
- [ ] New endpoints work (if created)
- [ ] No console errors when starting server
- [ ] Can register and login users

### Before Moving to Next Phase:
- [ ] All baseline tests pass
- [ ] All migrated functions work in new controllers
- [ ] Old routes still functional
- [ ] No breaking changes introduced

---

## CRITICAL RULES FOR AI ASSISTANTS

### ✅ ALWAYS DO:
1. Run tests after each file change
2. Create new files before modifying existing ones
3. Migrate one function at a time
4. Keep backup of working code
5. Test endpoints manually after code changes

### ❌ NEVER DO:
1. Modify multiple files in same step
2. Delete functions before confirming migration works
3. Change function names or signatures
4. Skip testing steps
5. Proceed if any test fails

### 🚨 EMERGENCY STOP CONDITIONS:
- Any test fails after a change
- Server won't start after a change  
- Any existing endpoint returns 500 error
- Cannot register or login users

**If any emergency condition occurs: STOP and ROLLBACK immediately**

---

This guide ensures AI tools can safely refactor without breaking functionality by following small, testable increments. 